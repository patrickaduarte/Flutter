﻿
<?php get_header(); ?>	



	<div id="wrapper">
	
		<div id="content-wrapper">
		
			<div id="content">
			
			
			<?php if (get_option('artsee_format') == 'Blog Style') { ?>
<?php include(TEMPLATEPATH . '/includes/blogstyle.php'); ?>
<?php } else { include(TEMPLATEPATH . '/includes/defaultindex.php'); } ?>

			
			
	
			</div>
		
		</div>
		<?php get_sidebar(); ?>    
		<?php get_footer(); ?>   
	
</body>
</html>