<script type="text/javascript"><!--
google_ad_client = "pub-6734752749309808";
/* 468x60, created 7/3/08 */
google_ad_slot = "2004770746";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>