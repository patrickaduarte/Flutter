﻿<div id="featured">
 <?php $my_query = new WP_Query('category_name=Featured Articles&showposts=1');
  while ($my_query->have_posts()) : $my_query->the_post();
  $do_not_duplicate = $post->ID; ?>

<h1 class="titles-featured"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h1>
<div class="featured-content">
<div class="thumbnail-div" style="width: 576px; margin-top: 15px; margin-bottom: 15px;"><a href="<?php the_permalink() ?>"><img height="106" width="576" style="border: none;" alt="featured article" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo get_post_meta($post->ID, "Featured", true); ?>&amp;h=106&amp;w=576&amp;zc=1" /></a></div>

			<?php the_content_limit(500, ""); ?>
			<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
			<div style="clear: both;"></div>
</div>
			
  <?php endwhile; ?>

</div>
			