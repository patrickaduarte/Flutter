﻿ <?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

			
<?php static $ctr = 0; 
if ($ctr == "$artsee_homepage_posts;") { break; } 
else { ?>

		<?php  $thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);	 ?>

<div class="home-post-wrap">
			<div class="post">


<div class="thumbnail-div" style="width: 263px; margin-bottom: 10px;">
<?php if($thumb !== '') { ?>
	<img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=108&amp;w=263&amp;zc=1"
	width="263px" height="108px"
	alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"
	/>
<?php } else { echo ''; } ?>
</div>

			
			<h2 class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '23') ?></a></h2>
			<?php the_content_limit(280, ""); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>

			</div>
			
</div>
<?php $ctr++; } ?>
			<?php comments_template(); ?>

			<?php endwhile; ?>
<div style="clear: both;"></div>
			   <p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>

			<?php else : ?>

			<h2 >No Results Found</h2>

			<p>Sorry, your search returned zero results. </p>

			<?php endif; ?>