﻿<div id="header-right">
<?php include 'adsense/468x60.php';?>
</div>