﻿
<?php get_header(); ?>	

<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>

	<div id="wrapper">
	
		<div id="content-wrapper">
		
			<div id="content">
			
			<div class="heading-content">
<div class="heading-left"></div>
<div class="heading-inside">Recent Entries</div>
<div class="heading-right"></div>
</div>

<!--Begin Feaured Article-->
<?php if (get_option('artsee_featured') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/featured.php'); } ?>
<!--End Feaured Article-->	
        	
		
<div id="left-inside">
<?php if (get_option('artsee_format') == 'Blog Style') { ?>
<?php include(TEMPLATEPATH . '/includes/blogstyle.php'); ?>
<?php } else { include(TEMPLATEPATH . '/includes/default.php'); } ?>
</div>
			
			
			
<!--Begin Tabbed Content-->
<?php if (get_option('artsee_tabs') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/tabs.php'); } ?>
<!--End Tabbed Content-->	
			
	
			</div>
		
		</div>
		<?php get_sidebar(); ?>    
		<?php get_footer(); ?>   
	
</body>
</html>