=== Plugin Name ===
Contributors: denishua
Tags: Related,Posts
Donate link: http://fairyfish.net/donate/
Requires at least: 2.3
Tested up to: 2.6.2
Stable tag: 1.0

WordPress Related Posts Plugin will generate a related posts via WordPress tags, and add the related posts to feed.

== Description ==

WordPress Related Posts Plugin will generate a related posts via WordPress tags, and add the related posts to feed.

Please search and submit your transaltion here: <a href="http://fairyfish.net/2008/06/06/wordpress-related-posts-plugin-translation/">http://fairyfish.net/2008/06/06/wordpress-related-posts-plugin-translation/</a> 

== Installation ==

1. Upload the folder WPRP to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php wp_related_posts(); ?>` in your templates
1. Navigate to Manage > Option > WordPress Related Posts to configure plugin output.


== Upgrade ==

1. Delete the old plugin folder `WP23RP`.
1. Upload the folder WPRP to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php wp_related_posts(); ?>` in your templates
1. Navigate to Manage > Option > WordPress Related Posts to configure plugin output.
