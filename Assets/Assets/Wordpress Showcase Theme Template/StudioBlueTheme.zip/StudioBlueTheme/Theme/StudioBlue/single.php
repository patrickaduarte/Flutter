﻿<?php get_header(); ?>	
<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
<div id="container">
<div id="left-div">
<div id="left-inside">

<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>

<!--Begin Post-->
<div class="post-wrapper">
<div style="clear: both;"></div>
<?php if (get_option('artsee_thumbnails') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/thumbnail.php'); } ?>
<h1 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h1>
<div class="post-info">Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('m jS, Y') ?> |  <a href="#respond" title="<?php _e("Leave a comment"); ?>"><?php comments_number('no responses','one response','% responses'); ?></a></div>
			
<div style="clear: both;"></div>
<div class="single-entry">

<?php the_content(); ?>

</div>

<?php if (get_option('artsee_posttabs') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/post-tabs.php'); } ?>


<?php if (get_option('artsee_foursixeight') == 'Enable') { ?>
<?php include(TEMPLATEPATH . '/includes/468x60.php'); ?>
<?php } else { echo ''; } ?>


<div style="clear: both;"></div>
<?php comments_template(); ?>

<?php endwhile; ?>

</div>

<?php else : ?>

<h2 align="center">Not Found</h2>

<p align="center">Sorry, but the page you requested could not be found.</p>

<?php endif; ?>			
	
</div>
		
</div>

<!--Begin Sidebar-->
<?php get_sidebar(); ?> 
<!--End Sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>
<!--End Footer-->
	
</body>
</html>