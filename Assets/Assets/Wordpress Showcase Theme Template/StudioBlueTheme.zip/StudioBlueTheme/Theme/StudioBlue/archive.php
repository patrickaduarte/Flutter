﻿<?php get_header(); ?>	

<div id="container">
	
<div id="left-div">
		
<div id="left-inside">
			
<?php if (have_posts()) : while (have_posts()) : the_post(); 
if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<div class="home-post-wrap2">

<div stlye="clear: both;"></div>

<!--Begin Post-->
<div class="single-entry">
<span class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '', true, '400') ?></a></span>
<div class="post-info">Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>
<?php the_content_limit(300, ""); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>
<!--End Post-->

</div>

<?php comments_template(); ?>

<?php endwhile; ?>

<div style="clear: both;"></div>


<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
else { ?>
<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>
<?php } ?>


<?php else : ?>

<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>

<?php endif; ?>
			
</div>
		
</div>

<!--Begin Sidebar-->
<?php get_sidebar(); ?>    
<!--End Sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>
<!--End Footer-->

</body>
</html>