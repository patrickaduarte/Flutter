﻿<!--Category Box 1-->
<div class="home-post-wrap-box">	
<span class="headings">Recent From <?php echo $artsee_home_cat_one_title; ?></span>
<?php $my_query = new WP_Query("cat=$artsee_home_cat_one_id&showposts=$artsee_home_cat_one_number");
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>

<div class="cat-box-items">
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?><?php // if there's a thumbnail
if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=25&amp;w=25&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" style="border: 3px solid #DCDCDC;" /></a>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<span class="titles-boxes"><a href="<?php the_permalink(); ?>"><?php the_title2('', '...', true, '35') ?></a></span>
</div>
<?php endwhile; ?>
</div>
<!--Category Box 1-->

<!--Category Box 2-->
<div class="home-post-wrap-box">	
<span class="headings">Recent From <?php echo $artsee_home_cat_two_title; ?></span>
<?php $my_query = new WP_Query("cat=$artsee_home_cat_two_id&showposts=$artsee_home_cat_two_number");
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>

<div class="cat-box-items">
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?><?php // if there's a thumbnail
if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=25&amp;w=25&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" style="border: 3px solid #DCDCDC;" /></a>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<span class="titles-boxes"><a href="<?php the_permalink(); ?>"><?php the_title2('', '...', true, '35') ?></a></span>
</div>
<?php endwhile; ?>
</div>
<!--Category Box 2-->
