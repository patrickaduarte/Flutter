<?php
// Includes
require_once( IPTEMP_LIBPATH . '/metabox/metabox.php');
require_once( IPTEMP_PATH . 'admin_meta.php');

// Register activation
register_activation_hook(__FILE__, 'iptemp_plugin_activate');

// Action on init
add_action( 'init', 'iptemp_admin_init');
add_action( 'admin_init', 'mail_subscribers_download');

function iptemp_admin_init()
{        
    add_action( 'admin_menu','iptemp_admin_actions');
    //add_action( 'admin_menu', 'add_some_box');    
    add_action( 'admin_print_scripts', 'iptemp_admin_scripts');
    add_action( 'admin_print_styles', 'iptemp_admin_styles');        
    //add_action( 'save_post', 'smashing_save_post_class_meta', 10, 2 );
    
    // Add delete action for cache
    iptempCache::init()->addDeleteAction();
}

function iptemp_admin() {
	global $wpdb;
	$db_prefix = $wpdb->prefix; 
	if(!current_user_can('manage_options') || !current_user_can('edit_posts')) {
		echo '<div id="message" class="error">'. __("You don't have permissions to use this plugin","newsletter-generator") .' </div>';
	} else {

	}
}


function iptemp_settings() {
        
        if($_REQUEST['iptemp_settings'] == 'true') {
            update_option( 'iphone_app_homepage_id', $_REQUEST['iphone_homepage_id'] );
            update_option( 'iptemp_cache', $_REQUEST['iptemp_cache'] );
        }

        echo '<h3>iPhone App Settings</h3>';
        echo '<form method="post" name="iptemp_settings">';
        
        // Set homepage
        echo '<h4>Set as homepage:</h4><p><select name="iphone_homepage_id"><option value="">None</option>';
        
        $args = array(
                     'post_type' => 'iphone-app-page',
                     'posts_per_page' => -1
                     //'paged' => ( get_query_var('paged') ? get_query_var('paged') : 1),
                     );
        query_posts($args);
        while (have_posts()) : the_post();
        
            if(get_option('iphone_app_homepage_id') == get_the_ID())
              echo '<option value="' . get_the_ID() . '" SELECTED>' . get_the_title() . '</option>';
            else
              echo '<option value="' . get_the_ID() . '">' . get_the_title() . '</option>';
        
        endwhile;
        
        echo '</select></p>';
        echo '<br />';
        // Cache
        echo '<h4>Cache App Pages to HTML:</h4>';
        echo '<small>Creates a prerengenerated HTML-file for your App Page. Improves the page loading up to 8 times.<br />* Requires <a href="http://nginx.org/" target="_blank">Nginx Webserver</a><br /><br />Instructions:<br /> 1. create wp-content/cache and make it writtable<br />2. Update Nginx rewrite with code below</small>';
        echo '<p><label>Yes </label>';
        $checked = get_option('iptemp_cache') ? ' checked ' : '';
        echo '<input type="radio" name="iptemp_cache" value="1" ' . $checked . '> ';
        echo '<label> No </label>';
        $checked = !get_option('iptemp_cache') ? ' checked ' : '';
        echo '<input type="radio" name="iptemp_cache" value="0" ' . $checked . '>';
        
        echo '<br />';
        echo '<br />';
        
        echo '<h4>Nginx Cache Rewrite Rule</h4>';
        echo '<small>Add/change your server section with the code below for your Nginx config.</small>';
        echo '<p><code>
        <pre>
location / {
    set $iptempcache_file /wp-content/cache/iptemp/$http_host/$uri/index.html;
    try_files $iptempcache_file $uri $uri/ /index.php?$args;
}</pre>
        </code></p>';
        
        echo '<input type="hidden" name="iptemp_settings" value="true" />';
        echo '<p><input type="submit" name="submit_form" class="button-primary" value="Update Settings" /></p>';
        echo '</form>';
}

function iptemp_admin_actions() {
	if(iptemp_check_user_permission()) {
            //add_options_page("iPhone App Settings","iPhone App Page Settings",1,"iPhone-App-Settings","iptemp_settings");  
            add_submenu_page("edit.php?post_type=iphone-app-page","settings","Settings","manage_options", "iphone-app-page-settings", "iptemp_settings");  
	}
}


function iptemp_admin_scripts() {
        if($_REQUEST['post_type'] == "iphone-app-page" || $_REQUEST['post'] != '') {
          wp_enqueue_script("jqueryagain", WP_PLUGIN_URL . "/iphone-templates/js/jquery-min.js");
        }
}

function iptemp_admin_styles() {
          wp_enqueue_style("iptemp_admin_css", WP_PLUGIN_URL . "/iphone-templates/css/iptemp-style.css" );
}

function iptemp_plugin_activate() {
	global $wpdb;
	$db_prefix = $wpdb->prefix; 

}

function iptemp_check_user_permission() {
	if(current_user_can('manage_options') || current_user_can('edit_posts'))
		return true;
	else 
		return false;
}

function iptemp_create_table($table_name, $sql) {
	global $wpdb;
        $db_prefix = $wpdb->prefix; 
	if($wpdb->get_var("show tables like '". $table_name . "'") != $table_name) {
		$wpdb->query($sql);
   }
}

function mail_subscribers_download() {
    
    if(isset($_REQUEST['get_mail_subscribers'])) {        
        $file = ABSPATH . '.email_subscribe_list.txt';

        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename='.basename($file));
            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();
            flush();
            readfile($file);
            exit;
        } else {
            die ("Ops, could not find the file $file?");
        }
        
        die("");    
    }
}

/*** BOXES ***/
function add_some_box() {      
    $posttype = IPTEMP_POST_TYPE;
    
    add_meta_box('iptemp-price-and-url','Applicataion $ and URL','iptemp_price_and_url_meta_box',$posttype,'side','default');
    add_meta_box('iptemp-contact-form','Contact Form','iptemp_contact_form_meta_box',$posttype,'side','default');
    add_meta_box('iptemp-color-scheme','Select a Color Scheme','iptemp_color_scheme_meta_box',$posttype,'side','default');
    add_meta_box('iptemp-logo-appname','Logo + AppName','iptemp_logo_appname_meta_box',$posttype,'normal','default');
    add_meta_box('iptemp-social-sharing','Social Sharing','iptemp_social_sharing_meta_box',$posttype,'normal','default');
    add_meta_box('iptemp-headline-body-text','Headline + body text','iptemp_headline_body_text_meta_box',$posttype,'normal','default');
    add_meta_box('iptemp-screenshots-popup','Screenshots, Pop-over Video and Features','iptemp_screenshots_popup_meta_box',$posttype,'normal','default');
    add_meta_box('iptemp-email-notifications','Email Subscription Form','iptemp_email_notifications_meta_box',$posttype,'normal','default');
    add_meta_box('iptemp-key-features','Key Features','iptemp_key_features_meta_box',$posttype,'normal','default');
    add_meta_box('iptemp-user-reviews','User Reviews','iptemp_user_reviews_meta_box',$posttype,'normal','default');
    add_meta_box('iptemp-about-us','About Us','iptemp_about_us_meta_box',$posttype,'normal','default');
    add_meta_box('iptemp-other-apps','About Us - Our other apps','iptemp_other_apps_meta_box',$posttype,'normal','default');
}

function iptemp_other_apps_meta_box($object, $box) { ?>
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_other_apps_nonce' ); ?>

        <p>
                <table border="0" class="iptemp_table" width="690">
                <tr>
                  <td colspan="2" align="right"><input class="button-primary" type="button" value="Add an App" id="add-an-app" /></td>
                </tr>
                <tr>
                  <td>App Name</td>
                  <td><input class="widefat" type="text" id="iptemp_app_name" size="30" /></td>
                </tr>                        
                <tr>
                  <td>URL</td>
                  <td><input class="widefat" type="text" id="iptemp_app_url" size="30" /></td>
                </tr>   
                <tr>
                  <td>Icon URL</td>
                  <td><small>Click &quot;Media&quot;, upload your image, copy and paste your image URL here.</small><br /><input class="widefat" type="text" id="iptemp_app_icon_url" size="30" style="margin: 3px 0;" /><br /><small>Icon image must be 67px x 67px. <a href="<?php echo WP_PLUGIN_URL; ?>/iphone-templates/images/app-icon-small-template.psd.zip" target="_blank">Click here</a> to download Photoshop template.</small></td>
                </tr>                                                
                <tr>
                  <td colspan="2" style="padding: 0;" id="other_apps_cont">
                  <?php 
                      $app_name_arr = get_post_meta( $object->ID, 'iptemp-app-name', true );
                      $app_url_arr = get_post_meta( $object->ID, 'iptemp-app-url', true );
                      $app_icon_url_arr = get_post_meta( $object->ID, 'iptemp-app-icon-url', true );
                      $other_apps_counter = 1;

                      for($x=0;$x<count($app_name_arr);$x++) {

                          if($app_name_arr[$x] != '') {
                              echo '<div class="app_icon_prev_cont app_prev_box' . $other_apps_counter . '"><img src="' . $app_icon_url_arr[$x] . '" /><div><a href="' . $app_url_arr[$x] . '" class="app_name">' . $app_name_arr[$x] . '</a></div><input class="button-primary" type="button" value="Delete" id="delete-user-review" onclick="iptemp_delete_other_apps(' . $other_apps_counter . ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" id="edit-user-review" onclick="iptemp_edit_other_apps(' . $other_apps_counter . ')" /><div class="clear"></div></div>  <div style="display: none;" class="app_icon_edit_cont app_edit_box' . $other_apps_counter . '"><table><tr><td>App Name</td><td><input class="widefat app-name" type="text" name="iptemp-app-name[]" size="30" value="' . $app_name_arr[$x] . '" /></td></tr><tr><td>URL</td><td><input class="widefat app-url" type="text" name="iptemp-app-url[]" size="30" value="' . $app_url_arr[$x] . '" /></td></tr><tr><td>Icon URL</td><td><input class="widefat app-icon-url" type="text" name="iptemp-app-icon-url[]" value="' . $app_icon_url_arr[$x] . '" size="30" /></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_other_apps(' . $other_apps_counter . ')" /></td></tr></table></div>';
                              $other_apps_counter++;
                          }
                      }
                  ?>
                  <input type="hidden" value="<?php echo $other_apps_counter; ?>" id="other_apps_counter" />
                  </td>
                </tr>
                </table>
        </p>

        <script type="text/javascript">
        function iptemp_edit_other_apps(app_num) {
            $('.app_prev_box'+app_num).css('display','none');
            $('.app_edit_box'+app_num).css('display','block');
        }

        function iptemp_delete_other_apps(app_num) {
            $('.app_prev_box'+app_num).remove();
            $('.app_edit_box'+app_num).remove();
        }                

        function iptemp_update_other_apps(app_num) {

            //update values of preview box
            $('.app_prev_box'+app_num+' img').attr("src",$('.app_edit_box'+app_num+' .app-icon-url').val());
            $('.app_prev_box'+app_num+' .app_name').html($('.app_edit_box'+app_num+' .app-name').val());
            $('.app_prev_box'+app_num+' .app_name').attr("href",$('.app_edit_box'+app_num+' .app-url').val());

            $('.app_prev_box'+app_num).css('display','block');
            $('.app_edit_box'+app_num).css('display','none');
        }                

        $('#add-an-app').click(function() {
            if($('#iptemp_app_name').val() == '') {
                alert('Please app name.');
            } else if($('#iptemp_app_icon_url').val() == '') {
                alert('Please input icon url.');
            } else {
                var current_num_box;
                current_num_box = $('#other_apps_counter').val();
                $('#other_apps_counter').val(current_num_box+1);

                $('#other_apps_cont').append('<div class="app_icon_prev_cont app_prev_box' + current_num_box + '"><img src="' + $('#iptemp_app_icon_url').val() + '" /><div><a href="' + $('#iptemp_app_url').val() + '" class="app_name">' + $('#iptemp_app_name').val() + '</a></div><input class="button-primary" type="button" value="Delete" id="delete-user-review" onclick="iptemp_delete_other_apps(' + current_num_box + ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" id="edit-user-review" onclick="iptemp_edit_other_apps(' + current_num_box + ')" /><div class="clear"></div></div>  <div style="display: none;" class="app_icon_edit_cont app_edit_box' + current_num_box + '"><table><tr><td>App Name</td><td><input class="widefat app-name" type="text" name="iptemp-app-name[]" size="30" value="' + $('#iptemp_app_name').val() + '" /></td></tr><tr><td>URL</td><td><input class="widefat app-url" type="text" name="iptemp-app-url[]" size="30" value="' + $('#iptemp_app_url').val() + '" /></td></tr><tr><td>Icon URL</td><td><input class="widefat app-icon-url" type="text" name="iptemp-app-icon-url[]" value="' + $('#iptemp_app_icon_url').val() + '" size="30" /></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_other_apps(' + current_num_box + ')" /></td></tr></table></div>');

                $('#iptemp_app_name').val('');
                $('#iptemp_app_url').val('');
                $('#iptemp_app_icon_url').val('');
            }
        });
      </script>                
<?php
}                                                

function iptemp_about_us_meta_box($object, $box) { ?>
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_about_us_nonce' ); ?>

        <p>
                <table border="0" class="iptemp_table">
                <tr>
                  <td>Module Title</td>
                  <td><input class="widefat" type="text" name="iptemp-about-us-title" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-about-us-title', true ) ); ?>" size="30" /></td>
                </tr>
                <tr>
                  <td>Company Bio</td>
                  <td><textarea class="widefat" id="iptemp_company-bio" name="iptemp-company-bio" style="width: 600px; height: 75px;"><?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-company-bio', true ) ); ?></textarea></td>
                </tr>                           
                <tr>
                  <td colspan="2"><b>Team Member 1</b></td>
                </tr>
                <tr>
                  <td>Name</td>
                  <td><input class="widefat" type="text" id="iptemp_team_member_name" size="30" /></td>
                </tr>                        
                <tr>
                  <td>Bio</td>
                  <td><textarea class="widefat" id="iptemp_team_member_bio" style="width: 600px; height: 75px;"></textarea></td>
                </tr>   
                <tr>
                  <td>Picture URL</td>
                  <td><input class="widefat" type="text" id="iptemp_team_member_picture" size="30" /></td>
                </tr>                           
                <tr>
                  <td colspan="2" align="center"><input class="button-primary" type="button" value="Add Team Member" id="add-team-member" /></td>
                </tr>                        
                <tr>
                  <td colspan="2" style="padding: 0;" id="team_member_cont">
                  <?php 
                      $member_name_arr = get_post_meta( $object->ID, 'iptemp-team-member-name', true );
                      $member_bio_arr = get_post_meta( $object->ID, 'iptemp-team-member-bio', true );
                      $member_picture_arr = get_post_meta( $object->ID, 'iptemp-team-member-picture', true );
                      $team_member_counter = 1;

                      for($x=0;$x<count($member_name_arr);$x++) {

                          if($member_name_arr[$x] != '') {
                              echo '<div class="team_member_prev_cont member_prev_box' . $team_member_counter . '"><img src="' . $member_picture_arr[$x] . '" width="77" height="84" /><div class="user_details"><b class="user_name">' . $member_name_arr[$x] . '</b><br /><span class="user_bio">' . $member_bio_arr[$x] . '</span></div><input class="button-primary" type="button" value="Delete" id="delete-user-review" onclick="iptemp_delete_team_member(' . $team_member_counter . ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" id="edit-user-review" onclick="iptemp_edit_team_member(' . $team_member_counter . ')" /><div class="clear"></div></div>  <div style="display: none;" class="team_member_edit_cont member_edit_box' . $team_member_counter . '"><table><tr><td>Name</td><td><input class="widefat member-name" type="text" name="iptemp-team-member-name[]" size="30" value="' . $member_name_arr[$x] . '" /></td></tr><tr><td>Bio</td><td><textarea class="widefat member-bio" name="iptemp-team-member-bio[]" style="width: 600px; height: 75px;">' . $member_bio_arr[$x] . '</textarea></td></tr><tr><td>Picture</td><td><input class="widefat member-picture" type="text" name="iptemp-team-member-picture[]" value="' . $member_picture_arr[$x] . '" size="30" /></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_team_member(' . $team_member_counter . ')" /></td></tr></table></div>';
                              $team_member_counter++;
                          }
                      }
                  ?>
                  <input type="hidden" value="<?php echo $team_member_counter; ?>" id="team_member_counter" />
                  </td>
                </tr>
                </table>
        </p>

        <script type="text/javascript">
        function iptemp_edit_team_member(member_num) {
            $('.member_prev_box'+member_num).css('display','none');
            $('.member_edit_box'+member_num).css('display','block');
        }

        function iptemp_delete_team_member(member_num) {
            $('.member_prev_box'+member_num).remove();
            $('.member_edit_box'+member_num).remove();
        }                

        function iptemp_update_team_member(member_num) {

            //update values of preview box
            $('.member_prev_box'+member_num+' img').attr("src",$('.member_edit_box'+member_num+' .member-picture').val());
            //$('.member_prev_box'+member_num+' h4').html($('.member_edit_box'+member_num+' .main_quote').val());
            $('.member_prev_box'+member_num+' .user_name').html($('.member_edit_box'+member_num+' .member-name').val());
            $('.member_prev_box'+member_num+' .user_bio').html($('.member_edit_box'+member_num+' .member-bio').val());

            $('.member_prev_box'+member_num).css('display','block');
            $('.member_edit_box'+member_num).css('display','none');
        }                

        $('#add-team-member').click(function() {
            if($('#iptemp_team_member_name').val() == '') {
                alert('Please input name.');
            } else if($('#iptemp_team_member_bio').val() == '') {
                alert('Please input bio.');
            } else {
                var current_num_box;
                current_num_box = $('#team_member_counter').val();
                $('#team_member_counter').val(current_num_box+1);

                $('#team_member_cont').append('<div class="team_member_prev_cont member_prev_box' + current_num_box + '"><img src="' + $('#iptemp_team_member_picture').val() + '" width="77" height="84" /><div class="user_details"><b class="user_name">' + $('#iptemp_team_member_name').val() + '</b><br /><span class="user_bio">' + $('#iptemp_team_member_bio').val() + '</span></div><input class="button-primary" type="button" value="Delete" id="delete-user-review" onclick="iptemp_delete_team_member(' + current_num_box + ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" id="edit-user-review" onclick="iptemp_edit_team_member(' + current_num_box + ')" /><div class="clear"></div></div>  <div style="display: none;" class="team_member_edit_cont member_edit_box' + current_num_box + '"><table><tr><td>Name</td><td><input class="widefat member-name" type="text" name="iptemp-team-member-name[]" size="30" value="' + $('#iptemp_team_member_name').val() + '" /></td></tr><tr><td>Bio</td><td><textarea class="widefat member-bio" name="iptemp-team-member-bio[]" style="width: 600px; height: 75px;">' + $('#iptemp_team_member_bio').val() + '</textarea></td></tr><tr><td>Picture</td><td><input class="widefat member-picture" type="text" name="iptemp-team-member-picture[]" value="' + $('#iptemp_team_member_picture').val() + '" size="30" /></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_team_member(' + current_num_box + ')" /></td></tr></table></div>');

                $('#iptemp_team_member_name').val('');
                $('#iptemp_team_member_bio').val('');
                $('#iptemp_team_member_picture').val('');
            }
        });
      </script>                
<?php
}                                        

function iptemp_user_reviews_meta_box($object, $box) { ?>
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_user_reviews_nonce' ); ?>

        <p>
                <table border="0" class="iptemp_table">
                <tr>
                  <td>Module Title</td>
                  <td><input class="widefat" type="text" name="iptemp-user-reviews-title" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-user-reviews-title', true ) ); ?>" size="30" /></td>
                </tr>
                <tr>
                  <td colspan="2"><b>User Review 1</b></td>
                </tr>
                <tr>
                  <td>Main Quote</td>
                  <td><input class="widefat" type="text" id="iptemp_main_quote" size="30" /></td>
                </tr>                        
                <tr>
                  <td>Body Quote</td>
                  <td><textarea class="widefat" id="iptemp_body_quote" style="width: 600px; height: 75px;"></textarea></td>
                </tr>   
                <tr>
                  <td>Name</td>
                  <td><input class="widefat" type="text" id="iptemp_user_review_name" size="30" /></td>
                </tr>                                                
                <tr>
                  <td colspan="2">URL text <input class="widefat" type="text" id="iptemp_user_review_url_text" style="width: 200px;" />&nbsp;&nbsp;&nbsp;URL link <input class="widefat" type="text" id="iptemp_user_review_url" style="width: 200px;" /></td>
                </tr>                            
                <tr>
                  <td colspan="2" align="center"><input class="button-primary" type="button" value="Add User Review" id="add-user-review" /></td>
                </tr>                        
                <tr>
                  <td colspan="2" style="padding: 0;" id="users_reviews_cont">
                  <?php 
                      $main_quote_arr = get_post_meta( $object->ID, 'iptemp-main-quote', true );
                      $body_quote_arr = get_post_meta( $object->ID, 'iptemp-body-quote', true );
                      $user_review_name_arr = get_post_meta( $object->ID, 'iptemp-user-review-name', true );
                      $user_review_url_text_arr = get_post_meta( $object->ID, 'iptemp-user-review-url-text', true );
                      $user_review_url_arr = get_post_meta( $object->ID, 'iptemp-user-review-url', true );
                      $review_box_counter = 1;

                      for($x=0;$x<count($main_quote_arr);$x++) {
                          if($main_quote_arr[$x] != '') {
                              echo '<div class="user_review_prev_cont review_prev_box' . $review_box_counter . '"><div class="user_review_prev_box"><h4>' . $main_quote_arr[$x] . '</h4><p class="body_quote">' , $body_quote_arr[$x] . '</p><p align="right"><span class="review_name">' . $user_review_name_arr[$x] . '</span>, <a class="review_url" href="' . $user_review_url_arr[$x] . '">' . $user_review_url_text_arr[$x] . '</a></p></div>  <div class="user_review_prev_edit_box"><br /><input class="button-primary" type="button" value="Delete" onclick="iptemp_delete_review(' . $review_box_counter . ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" onclick="iptemp_edit_review(' . $review_box_counter . ')" /><div class="clear"></div></div><div class="clear"></div></div><div style="display: none;" class="user_review_prev_cont review_edit_box' . $review_box_counter . '"><table><tr><td>Main Quote</td><td><input class="widefat main_quote" type="text" name="iptemp-main-quote[]" value="' . $main_quote_arr[$x] . '" size="30" /></td></tr><tr><td>Body Quote</td><td><textarea class="widefat body_quote" name="iptemp-body-quote[]" style="width: 600px; height: 75px;">' . $body_quote_arr[$x] . '</textarea></td></tr><tr><td>Name</td><td><input class="widefat review_name" type="text" name="iptemp-user-review-name[]" value="' . $user_review_name_arr[$x] . '" size="30" /></td></tr><tr><td colspan="2">URL text <input class="widefat review_url_text" type="text"  name="iptemp-user-review-url-text[]" value="' . $user_review_url_text_arr[$x] . '" style="width: 200px;" />&nbsp;&nbsp;&nbsp;URL link <input class="widefat review_url" type="text" name="iptemp-user-review-url[]" value="' . $user_review_url_arr[$x] . '" style="width: 200px;" /></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_review(' . $review_box_counter . ')" /></td></tr></table></div>';
                              $review_box_counter++;
                          }
                      }
                  ?>
                  <input type="hidden" value="<?php echo $review_box_counter; ?>" id="review_box_counter" />
                  </td>
                </tr>
                </table>
        </p>

        <script type="text/javascript">
        function iptemp_edit_review(review_num) {
            $('.review_prev_box'+review_num).css('display','none');
            $('.review_edit_box'+review_num).css('display','block');
        }

        function iptemp_delete_review(review_num) {
            $('.review_prev_box'+review_num).remove();
            $('.review_edit_box'+review_num).remove();
        }                

        function iptemp_update_review(review_num) {

            //update values of preview box
            $('.review_prev_box'+review_num+' h4').html($('.review_edit_box'+review_num+' .main_quote').val());
            $('.review_prev_box'+review_num+' p.body_quote').html($('.review_edit_box'+review_num+' .body_quote').val());
            $('.review_prev_box'+review_num+' span.review_name').html($('.review_edit_box'+review_num+' .review_name').val());
            $('.review_prev_box'+review_num+' a.review_url').attr("href",$('.review_edit_box'+review_num+' .review_url').val());
            $('.review_prev_box'+review_num+' a.review_url').html($('.review_edit_box'+review_num+' .review_url_text').val());

            $('.review_prev_box'+review_num).css('display','block');
            $('.review_edit_box'+review_num).css('display','none');
        }                

        $('#add-user-review').click(function() {
            if($('#iptemp_main_quote').val() == '') {
                alert('Please input main quote.');
            } else if($('#iptemp_body_quote').val() == '') {
                alert('Please input body quote.');
            } else {
                var current_num_box;
                current_num_box = $('#review_box_counter').val();
                $('#review_box_counter').val(current_num_box+1);

                $('#users_reviews_cont').append('<div class="user_review_prev_cont review_prev_box' + current_num_box + '"><div class="user_review_prev_box"><h4>' + $('#iptemp_main_quote').val() + '</h4><p class="body_quote">' + $('#iptemp_body_quote').val() + '</p><p align="right"><span class="review_name">' + $('#iptemp_user_review_name').val() + '</span>, <a class="review_url" href="' + $('#iptemp_user_review_url').val() + '">' + $('#iptemp_user_review_url_text').val() + '</a></p></div>  <div class="user_review_prev_edit_box"><br /><input class="button-primary" type="button" value="Delete" onclick="iptemp_delete_review(' + current_num_box + ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" onclick="iptemp_edit_review(' + current_num_box + ')" /><div class="clear"></div></div><div class="clear"></div></div><div style="display: none;" class="user_review_prev_cont review_edit_box' + current_num_box + '"><table><tr><td>Main Quote</td><td><input class="widefat main_quote" type="text" name="iptemp-main-quote[]" value="' + $('#iptemp_main_quote').val() + '" size="30" /></td></tr><tr><td>Body Quote</td><td><textarea class="widefat body_quote" name="iptemp-body-quote[]" style="width: 600px; height: 75px;">' + $('#iptemp_body_quote').val() + '</textarea></td></tr><tr><td>Name</td><td><input class="widefat review_name" type="text" name="iptemp-user-review-name[]" value="' + $('#iptemp_user_review_name').val() + '" size="30" /></td></tr><tr><td colspan="2">URL text <input class="widefat review_url_text" type="text" name="iptemp-user-review-url-text[]" value="' + $('#iptemp_user_review_url_text').val() + '" style="width: 200px;" />&nbsp;&nbsp;&nbsp;URL link <input class="widefat" type="text review_url" name="iptemp-user-review-url[]" value="' + $('#iptemp_user_review_url').val() + '" style="width: 200px;" /></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_review(' + current_num_box + ')" /></td></tr></table></div>');

                $('#iptemp_main_quote').val('');
                $('#iptemp_body_quote').val('');
                $('#iptemp_user_review_name').val('');
                $('#iptemp_user_review_url').val('')
                $('#iptemp_user_review_url_text').val('');
            }
        });
      </script>                
<?php
}                                

function iptemp_key_features_meta_box($object, $box) { ?>
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_key_features_nonce' ); ?>

        <p>
                <table border="0" class="iptemp_table">
                <tr>
                  <td>Key Feature Title</td>
                  <td><input class="widefat" type="text" name="iptemp-key-features-title" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-key-features-title', true ) ); ?>" size="30" /></td>
                </tr>
                <tr>
                  <td colspan="2"><b>Key Feature</b></td>
                </tr>                        
                <tr>
                  <td>Body</td>
                  <td><textarea class="widefat" id="iptemp_feature_body" style="width: 600px; height: 75px;"></textarea></td>
                </tr>                                  
                <tr>
                  <td colspan="2" style="padding: 0;" id="key_features_cont">
                  <?php                       
                      $body_quote_arr = get_post_meta( $object->ID, 'iptemp-feature-body', true );
                      $key_features_box_counter = 1;

                      for($x=0;$x<count($main_quote_arr);$x++) {
                          if($main_quote_arr[$x] != '') {
                              echo '<div class="key_features_prev_cont key_features_prev_box' . $key_features_box_counter . '"><div class="key_features_prev_box"><h4>' . $main_quote_arr[$x] . '</h4><p class="body_quote">' , $body_quote_arr[$x] . '</p><p align="right"><span class="review_name">' . $user_review_name_arr[$x] . '</span>, <a class="review_url" href="' . $user_review_url_arr[$x] . '">' . $user_review_url_text_arr[$x] . '</a></p></div>  <div class="user_review_prev_edit_box"><br /><input class="button-primary" type="button" value="Delete" onclick="iptemp_delete_review(' . $review_box_counter . ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" onclick="iptemp_edit_review(' . $review_box_counter . ')" /><div class="clear"></div></div><div class="clear"></div></div><div style="display: none;" class="user_review_prev_cont review_edit_box' . $review_box_counter . '"><table><tr><td>Main Quote</td><td><input class="widefat main_quote" type="text" name="iptemp-main-quote[]" value="' . $main_quote_arr[$x] . '" size="30" /></td></tr><tr><td>Body Quote</td><td><textarea class="widefat body_quote" name="iptemp-body-quote[]" style="width: 600px; height: 75px;">' . $body_quote_arr[$x] . '</textarea></td></tr><tr><td>Name</td><td><input class="widefat review_name" type="text" name="iptemp-user-review-name[]" value="' . $user_review_name_arr[$x] . '" size="30" /></td></tr><tr><td colspan="2">URL text <input class="widefat review_url_text" type="text"  name="iptemp-user-review-url-text[]" value="' . $user_review_url_text_arr[$x] . '" style="width: 200px;" />&nbsp;&nbsp;&nbsp;URL link <input class="widefat review_url" type="text" name="iptemp-user-review-url[]" value="' . $user_review_url_arr[$x] . '" style="width: 200px;" /></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_review(' . $review_box_counter . ')" /></td></tr></table></div>';
                              $key_features_box_counter++;
                          }
                      }
                  ?>
                  <input type="hidden" value="<?php echo $review_box_counter; ?>" id="review_box_counter" />
                  </td>
                </tr>
                </table>
        </p>

        <script type="text/javascript">
        function iptemp_edit_review(review_num) {
            $('.review_prev_box'+review_num).css('display','none');
            $('.review_edit_box'+review_num).css('display','block');
        }

        function iptemp_delete_review(review_num) {
            $('.review_prev_box'+review_num).remove();
            $('.review_edit_box'+review_num).remove();
        }                

        function iptemp_update_review(review_num) {

            //update values of preview box
            $('.review_prev_box'+review_num+' h4').html($('.review_edit_box'+review_num+' .main_quote').val());
            $('.review_prev_box'+review_num+' p.body_quote').html($('.review_edit_box'+review_num+' .body_quote').val());
            $('.review_prev_box'+review_num+' span.review_name').html($('.review_edit_box'+review_num+' .review_name').val());
            $('.review_prev_box'+review_num+' a.review_url').attr("href",$('.review_edit_box'+review_num+' .review_url').val());
            $('.review_prev_box'+review_num+' a.review_url').html($('.review_edit_box'+review_num+' .review_url_text').val());

            $('.review_prev_box'+review_num).css('display','block');
            $('.review_edit_box'+review_num).css('display','none');
        }                

        $('#add-user-review').click(function() {
            if($('#iptemp_main_quote').val() == '') {
                alert('Please input main quote.');
            } else if($('#iptemp_body_quote').val() == '') {
                alert('Please input body quote.');
            } else {
                var current_num_box;
                current_num_box = $('#review_box_counter').val();
                $('#review_box_counter').val(current_num_box+1);

                $('#users_reviews_cont').append('<div class="user_review_prev_cont review_prev_box' + current_num_box + '"><div class="user_review_prev_box"><h4>' + $('#iptemp_main_quote').val() + '</h4><p class="body_quote">' + $('#iptemp_body_quote').val() + '</p><p align="right"><span class="review_name">' + $('#iptemp_user_review_name').val() + '</span>, <a class="review_url" href="' + $('#iptemp_user_review_url').val() + '">' + $('#iptemp_user_review_url_text').val() + '</a></p></div>  <div class="user_review_prev_edit_box"><br /><input class="button-primary" type="button" value="Delete" onclick="iptemp_delete_review(' + current_num_box + ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" onclick="iptemp_edit_review(' + current_num_box + ')" /><div class="clear"></div></div><div class="clear"></div></div><div style="display: none;" class="user_review_prev_cont review_edit_box' + current_num_box + '"><table><tr><td>Main Quote</td><td><input class="widefat main_quote" type="text" name="iptemp-main-quote[]" value="' + $('#iptemp_main_quote').val() + '" size="30" /></td></tr><tr><td>Body Quote</td><td><textarea class="widefat body_quote" name="iptemp-body-quote[]" style="width: 600px; height: 75px;">' + $('#iptemp_body_quote').val() + '</textarea></td></tr><tr><td>Name</td><td><input class="widefat review_name" type="text" name="iptemp-user-review-name[]" value="' + $('#iptemp_user_review_name').val() + '" size="30" /></td></tr><tr><td colspan="2">URL text <input class="widefat review_url_text" type="text" name="iptemp-user-review-url-text[]" value="' + $('#iptemp_user_review_url_text').val() + '" style="width: 200px;" />&nbsp;&nbsp;&nbsp;URL link <input class="widefat" type="text review_url" name="iptemp-user-review-url[]" value="' + $('#iptemp_user_review_url').val() + '" style="width: 200px;" /></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_review(' + current_num_box + ')" /></td></tr></table></div>');

                $('#iptemp_main_quote').val('');
                $('#iptemp_body_quote').val('');
                $('#iptemp_user_review_name').val('');
                $('#iptemp_user_review_url').val('')
                $('#iptemp_user_review_url_text').val('');
            }
        });
      </script>                
<?php
}                      

function iptemp_email_notifications_meta_box($object, $box) { ?>
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_email_notifications_nonce' ); ?>

        <p>
                <table border="0" class="iptemp_table">
                <tr>
                  <td colspan="2" style="width: 675px;">
                      All email addresses collected with the email subscriber and can be downloaded from 
                      <a target="_blank" href="<?php echo home_url()?>/wp-admin/edit.php?post_type=iphone-app-page&get_mail_subscribers=true">here</a>
                  </td>
                </tr>
                <tr>
                  <td>Headline</td>
                  <td><input class="widefat" type="text" name="iptemp-email-headline" value="<?php if(esc_attr( get_post_meta( $object->ID, 'iptemp-email-headline', true )) != '') { echo esc_attr( get_post_meta( $object->ID, 'iptemp-email-headline', true ) ); } else { echo 'Update me when something tremendous happens.'; } ?>" size="30" /></td>
                </tr>
                <tr>
                  <td>Body Text</td>
                  <td><textarea class="widefat" name="iptemp-email-body-text" style="width: 600px; height: 75px;"><?php if(esc_attr( get_post_meta( $object->ID, 'iptemp-email-body-text', true ) ) != '') { echo esc_attr( get_post_meta( $object->ID, 'iptemp-email-body-text', true ) ); } else { echo 'The app launch plan blurb can go here. Sign up to find out when the app goes live.'; }; ?></textarea></td>
                </tr>   <!--
                <tr>
                  <td>Button Text</td>
                  <td><input class="widefat" type="text" name="iptemp-button-text" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-button-text', true ) ); ?>" size="30" /></td>
                </tr>       -->                     
                </table>
        </p>
<?php
}                        

function iptemp_screenshots_popup_meta_box($object, $box) { //not yet added in save ?>
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_screenshots_popup_nonce' ); ?>

        <script type="text/javascript">
        function show_screenshot_fields() {
            $('.screenshot_fields_cont').css('display','block');
            $('.video_fields_cont').css('display','none');
            $('#iptemp_add_what').val('screenshot');
            $('#iptemp_video_screenshot_description').val('<h2>This is the headline</h2>And this is the rest of the copy. They can only enter 100 characters so the copy will fit in the box.');
        }

        function show_video_fields() {
            $('.screenshot_fields_cont').css('display','none');
            $('.video_fields_cont').css('display','block');                
            $('#iptemp_add_what').val('video');
            $('#iptemp_video_screenshot_description').val('');
        }
      </script>

        <p>
                <table border="0" class="iptemp_table w_800">
                <tr>
                  <td colspan="2" align="center"><b>Add a <input class="button-primary" type="button" value="Screenshot" onclick="show_screenshot_fields()" /> <input class="button-primary" type="button" value="Video" onclick="show_video_fields()" /> (5 maximum)</b></td>
                </tr>
                <tr>
                  <td style="padding:0;"><input type="hidden" id="iptemp_add_what" value="screenshot" />
                      <table border="0" class="iptemp_table w_800">
                      <tr class="screenshot_fields_cont">
                        <td colspan="2">Add your app screenshot and descriptive copy for the image. Use a &lt;h2&gt; tag for the headline. 100 character limit.</td>
                      </tr>
                      <tr>
                        <td colspan="2" class="screenshot_fields_cont"><b>Image URL:</b> (Click &quot;Media&quot;, upload your image, copy and paste your image URL here. Make sure your screenshots are sized 640px w x 960px h)<br /><input class="widefat" type="text" id="iptemp_video_screenshot" size="30" style="margin-top: 3px;" /></td>
                      </tr>
                      <tr>
                        <td colspan="2"><span class="video_fields_cont"><b>Video Embed Code:</b> (max height: 315 | max width: 560)</span><br /><textarea class="widefat" id="iptemp_video_screenshot_description"><h2>This is the headline</h2>And this is the rest of the copy. They can only enter 100 characters so the copy will fit in the box.</textarea></td>
                      </tr>
                      </table>
                  </td>
                <tr>
                  <td align="right"><input class="button-primary" type="button" value="Save" id="save-screen-vid" /></td>
                </tr>
                <tr>
                  <td colspan="2" style="padding: 0;" id="vid_screen_cont">
                  <?php
                      $image_url_arr = get_post_meta( $object->ID, 'iptemp-image-url', true );
                      $image_desc_arr = get_post_meta( $object->ID, 'iptemp-image-description', true );

                      $vid_screen_counter = 1;

                      for($x=0;$x<count($image_url_arr);$x++) {

                          if($image_url_arr[$x] != '') {

                              if($image_url_arr[$x] == '--not applicable--') { //if video then show a different preview and image url field hidden
                                  echo '<div class="screen_vid_prev_cont screen_vid_prev_box' . $vid_screen_counter . '">' . $image_desc_arr[$x] . '<input class="button-primary" type="button" value="Delete" onclick="iptemp_delete_screen_vid(' . $vid_screen_counter . ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" onclick="iptemp_edit_screen_vid(' . $vid_screen_counter . ')" /><div class="clear"></div></div>  <div style="display: none;" class="screen_vid_edit_cont screen_vid_edit_box' . $vid_screen_counter . '"><table width="100%"><tr style="display:none;"><td>Image URL</td><td><input class="widefat image-url" type="text" name="iptemp-image-url[]" size="30" value="--not applicable--" /></td></tr><tr><td>Video Embed Code:</td><td><textarea class="widefat image-description" name="iptemp-image-description[]">' . $image_desc_arr[$x] . ' </textarea></td></tr><tr><td colspan="2" align="right"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_screen_vid(' . $vid_screen_counter . ')" /></td></tr></table></div>';
                                  $vid_screen_counter++;
                              } else {
                                  echo '<div class="screen_vid_prev_cont screen_vid_prev_box' . $vid_screen_counter . '"><img src="' . $image_url_arr[$x] . '" width="60" height="95" /><div class="screen_vid_desc">' . $image_desc_arr[$x] . '</div><input class="button-primary" type="button" value="Delete" onclick="iptemp_delete_screen_vid(' . $vid_screen_counter . ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" onclick="iptemp_edit_screen_vid(' . $vid_screen_counter . ')" /><div class="clear"></div></div>  <div style="display: none;" class="screen_vid_edit_cont screen_vid_edit_box' . $vid_screen_counter . '"><table width="100%"><tr><td>Image URL</td><td><input class="widefat image-url" type="text" name="iptemp-image-url[]" size="30" value="' . $image_url_arr[$x] . '" /></td></tr><tr><td>Description</td><td><textarea class="widefat image-description" name="iptemp-image-description[]">' . $image_desc_arr[$x] . '</textarea></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_screen_vid(' . $vid_screen_counter . ')" /></td></tr></table></div>';
                                  $vid_screen_counter++;
                              }
                          }
                      }                          

                  ?>

                  <input type="hidden" value="<?php echo $vid_screen_counter; ?>" id="vid_screen_counter" />
                  </td>
                </tr>
                </table>
        </p>

        <script type="text/javascript">
        function iptemp_edit_screen_vid(screen_vid_num) {
            $('.screen_vid_prev_box'+screen_vid_num).css('display','none');
            $('.screen_vid_edit_box'+screen_vid_num).css('display','block');
        }

        function iptemp_delete_screen_vid(screen_vid_num) {
            $('.screen_vid_prev_box'+screen_vid_num).remove();
            $('.screen_vid_edit_box'+screen_vid_num).remove();
        }

        function iptemp_update_screen_vid(screen_vid_num) {

            //update values of preview box
            $('.screen_vid_prev_box'+screen_vid_num+' img').attr("src",$('.screen_vid_edit_box'+screen_vid_num+' .image-url').val());
            $('.screen_vid_prev_box'+screen_vid_num+' .screen_vid_desc').html($('.screen_vid_edit_box'+screen_vid_num+' .image-description').val());

            $('.screen_vid_prev_box'+screen_vid_num).css('display','block');
            $('.screen_vid_edit_box'+screen_vid_num).css('display','none');
        }                

        $('#save-screen-vid').click(function() {
            var current_num_box;
            current_num_box = $('#vid_screen_counter').val();                

            if(current_num_box > 5) {
                alert('You have reached the maximum of 5.');
                //alert(current_num_box);
            } else if($('#iptemp_video_screenshot').val() == '' && $('#iptemp_add_what').val() == 'screenshot') { //if screenshot then make image url required
                alert('Please input video or image url.');
            } else if($('#iptemp_video_screenshot_description').val() == '' && $('#iptemp_add_what').val() == 'video') { //if video then make embed code required
            } else {

                $('#vid_screen_counter').val(Number(current_num_box)+1);

                if($('#iptemp_add_what').val() == 'screenshot') {

                    $('#vid_screen_cont').append('<div class="screen_vid_prev_cont screen_vid_prev_box' + current_num_box + '"><img src="' + $('#iptemp_video_screenshot').val() + '" width="60" height="95" /><div class="screen_vid_desc">' + $('#iptemp_video_screenshot_description').val() + '</div><input class="button-primary" type="button" value="Delete" onclick="iptemp_delete_screen_vid(' + current_num_box + ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" onclick="iptemp_edit_screen_vid(' + current_num_box + ')" /><div class="clear"></div></div>  <div style="display: none;" class="screen_vid_edit_cont screen_vid_edit_box' + current_num_box + '"><table width="100%"><tr><td>Image URL</td><td><input class="widefat image-url" type="text" name="iptemp-image-url[]" size="30" value="' + $('#iptemp_video_screenshot').val() + '" /></td></tr><tr><td>Description</td><td><textarea class="widefat image-description" name="iptemp-image-description[]">' + $('#iptemp_video_screenshot_description').val() + '</textarea></td></tr><tr><td colspan="2"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_screen_vid(' + current_num_box + ')" /></td></tr></table></div>');

                } else { //else if video, hide image url fields and different preview format

                    $('#vid_screen_cont').append('<div class="screen_vid_prev_cont screen_vid_prev_box' + current_num_box + '">' + $('#iptemp_video_screenshot_description').val() + '<input class="button-primary" type="button" value="Delete" onclick="iptemp_delete_screen_vid(' + current_num_box + ')" />&nbsp;&nbsp;<input class="button-primary" type="button" value="Edit" onclick="iptemp_edit_screen_vid(' + current_num_box + ')" /><div class="clear"></div></div>  <div style="display: none;" class="screen_vid_edit_cont screen_vid_edit_box' + current_num_box + '"><table width="100%"><tr style="display:none;"><td>Image URL</td><td><input class="widefat image-url" type="text" name="iptemp-image-url[]" size="30" value="--not applicable--" /></td></tr><tr><td>Video Embed Code:</td><td><textarea class="widefat image-description" name="iptemp-image-description[]">' + $('#iptemp_video_screenshot_description').val() + '</textarea></td></tr><tr><td colspan="2" align="right"><input class="button-primary" type="button" value="Update" onclick="iptemp_update_screen_vid(' + current_num_box + ')" /></td></tr></table></div>');                        

                }

                $('#iptemp_video_screenshot').val('');
                $('#iptemp_video_screenshot_description').val('');
                /*$('#iptemp_video_screenshot_description').val('<h2>This is the headline</h2>And this is the rest of the copy. They can only enter 100 characters so the copy will fit in the box.');*/
            }
        });
      </script>                                
<?php
}                        


function iptemp_headline_body_text_meta_box($object, $box) { ?>
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_headline_body_text_nonce' ); ?>

        <p>
                <table border="0" class="iptemp_table">
                <tr>
                  <td>Headline</td>
                  <td><input class="widefat" type="text" name="iptemp-headline" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-headline', true ) ); ?>" size="30" /></td>
                </tr>
                <tr>
                  <td>Body Text</td>
                  <td><textarea class="widefat" name="iptemp-body-text" style="width: 600px; height: 75px;"><?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-body-text', true ) ); ?></textarea></td>
                </tr>                        
                </table>
        </p>
<?php
}                

function iptemp_social_sharing_meta_box($object, $box) { ?>
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_social_sharing_nonce' ); ?>

        <p>
                <table border="0" class="iptemp_table">
                <tr>
                  <td colspan="2"><i>These are the links that appear in the upper right of the site.</i></td>
                </tr>                        
                <tr>
                  <td>Twitter ID @ </td>
                  <td><input class="widefat" type="text" name="iptemp-twitter-id" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-twitter-id', true ) ); ?>" size="30" /></td>
                </tr>
                <tr>
                  <td>Facebook URL</td>
                  <td><input class="widefat" type="text" name="iptemp-facebook-url" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-facebook-url', true ) ); ?>" size="30" /></td>
                </tr>                        
                </table>
        </p>
<?php
}


function iptemp_logo_appname_meta_box($object, $box) { ?>
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_logo_appname_nonce' ); ?>

        <p>
                <table border="0" class="iptemp_table">
              <!--  <tr>
                  <td><input class="button-primary" type="button" value="Upload App Icon" /></td>
                  <td>Browse for Application Icon (image must be 144 x 144px) click here for app icon template</td>
                </tr>                        -->
                <tr>
                  <td>APP Icon URL</td>
                  <td><small>Click &quot;Media&quot;, upload your image, copy and paste your image URL here.</small><br /><input class="widefat" type="text" name="iptemp-top-app-icon-url" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-top-app-icon-url', true ) ); ?>" size="30" style="margin: 3px 0;" /> <small>Icon image must be 87px x 87px. <a href="<?php echo WP_PLUGIN_URL; ?>/iphone-templates/images/app-icon-large-template.psd.zip" target="_blank">Click here</a> to download the Photoshop template.</small></td>
                </tr>
                <tr>
                  <td>Application Name</td>
                  <td><input class="widefat" type="text" name="iptemp-appname" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-appname', true ) ); ?>" size="30" /></td>
                </tr>
                <tr>
                  <td>Application Tagline</td>
                  <td><input class="widefat" type="text" name="iptemp-apptagline" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-apptagline', true ) ); ?>" size="30" /></td>
                </tr>                        
                </table>
        </p>
<?php
}

function iptemp_color_scheme_meta_box( $object, $box ) { return true; ?>
          
        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_color_scheme_nonce' ); ?>

        <?php 
          $curr_scheme = get_post_meta( $object->ID, 'iptemp-color-scheme-name', true ); 
          if($curr_scheme == '')
              $curr_scheme = 'white-green';
        ?>

        <input type="hidden" name="iptemp-color-scheme-name" id="iptemp_color_scheme" value="<?php echo $curr_scheme; ?>" />

        <div class="color_scheme_cont">
            <img src="<?php echo WP_PLUGIN_URL; ?>/iphone-templates/images/iphone-theme-black-green.png" alt="black-green" <
                 ?php if($curr_scheme == 'black-green') { echo 'class="current_scheme"'; } ?> />
            <img src="<?php echo WP_PLUGIN_URL; ?>/iphone-templates/images/iphone-theme-black-orange.png" alt="black-orange" <?php if($curr_scheme == 'black-orange') { echo 'class="current_scheme"'; } ?> />
            <div class="clear"></div>
            <img src="<?php echo WP_PLUGIN_URL; ?>/iphone-templates/images/iphone-theme-black-red.png" alt="black-red" <?php if($curr_scheme == 'black-red') { echo 'class="current_scheme"'; } ?> />
            <img src="<?php echo WP_PLUGIN_URL; ?>/iphone-templates/images/iphone-theme-white-orange.png" alt="white-orange" <?php if($curr_scheme == 'white-orange') { echo 'class="current_scheme"'; } ?> />
            <div class="clear"></div>
            <img src="<?php echo WP_PLUGIN_URL; ?>/iphone-templates/images/iphone-theme-white-green.png" alt="white-green" <?php if($curr_scheme == 'white-green') { echo 'class="current_scheme"'; } ?> />
            <img src="<?php echo WP_PLUGIN_URL; ?>/iphone-templates/images/iphone-theme-white-red.png" alt="white-red" <?php if($curr_scheme == 'white-red') { echo 'class="current_scheme"'; } ?> />
            <div class="clear"></div>
        </div><!--//color_scheme_cont-->

        <script type="text/javascript">
        $('.color_scheme_cont img').click(function() {
            $('.color_scheme_cont img').removeClass('current_scheme');
            $(this).addClass('current_scheme');
            //alert($(this).attr('alt'));
            $('#iptemp_color_scheme').val($(this).attr('alt'));
        });
      </script>                

<?php }                                

function iptemp_contact_form_meta_box( $object, $box ) { ?>

        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_contact_form_nonce' ); ?>

        <table width="100%" border="0" class="iptemp_table">
        <tr>
          <td>Email</td>
          <td><input class="widefat" type="text" name="iptemp-contact-form-email" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-contact-form-email', true ) ); ?>" width="100%" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><i>Enter the email address where you want all contact form inquiries to be sent (leave blank to hide).</i></td>
        </tr>
        </table>
<?php }                        

/* Display the post meta box. */
function iptemp_price_and_url_meta_box( $object, $box ) { ?>

        <?php wp_nonce_field( basename( __FILE__ ), 'iptemp_price_and_url_nonce' ); ?>

        <table width="100%" border="0" class="iptemp_table">
        <tr>
          <td>Price</td>
          <td><input class="widefat" type="text" name="iptemp-app-price" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-app-price', true ) ); ?>" width="100%" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><i>This is the price that appears on the "Available in the App Store" button. If you app hasn't launched, write "Coming Soon".</i></td>
        </tr>
        <tr>
          <td>iTunes URL</td>
          <td><input class="widefat" type="text" name="iptemp-app-itunes-url" value="<?php echo esc_attr( get_post_meta( $object->ID, 'iptemp-app-itunes-url', true ) ); ?>" width="100%" /></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><i>This is where they click to buy the app. If the app isn't live yet, just leave this blank and there will be no click-thru URL.</i></td>
        </tr>
        </table>
<?php }                

/* Display the post meta box. */
function smashing_post_class_meta_box( $object, $box ) { ?>

        <?php wp_nonce_field( basename( __FILE__ ), 'smashing_post_class_nonce' ); ?>

        <p>
                <label for="smashing-post-class"><?php _e( "Add a custom CSS class, which will be applied to WordPress' post class.", 'example' ); ?></label>
                <br />
                <input class="widefat" type="text" name="smashing-post-class" id="smashing-post-class" value="<?php echo esc_attr( get_post_meta( $object->ID, 'smashing-post-class', true ) ); ?>" size="30" />
        </p>
<?php }        


/* Save the meta box's post metadata. */
function smashing_save_post_class_meta( $post_id, $post ) {

        $new_meta_boxes = array (
//                    "smashing-post-class" => array("name" => "smashing-post-class", "nonce" => "smashing_post_class"),
            "iptemp-logo-appname" => array("name" => "iptemp-appname", "nonce" => "iptemp_logo_appname"),
            "iptemp-logo-appname2" => array("name" => "iptemp-apptagline", "nonce" => "iptemp_logo_appname"),
            "iptemp-logo-appname3" => array("name" => "iptemp-top-app-icon-url", "nonce" => "iptemp_logo_appname"),
            "iptemp-social-sharing" => array("name" => "iptemp-twitter-id", "nonce" => "iptemp_social_sharing"),
            "iptemp-social-sharing2" => array("name" => "iptemp-facebook-url", "nonce" => "iptemp_social_sharing"),
            "iptemp-headline-body-text" => array("name" => "iptemp-headline", "nonce" => "iptemp_headline_body_text"),
            "iptemp-headline-body-text2" => array("name" => "iptemp-body-text", "nonce" => "iptemp_headline_body_text"),
            "iptemp-email-notifications" => array("name" => "iptemp-email-headline", "nonce" => "iptemp_email_notifications"),
            "iptemp-email-notifications2" => array("name" => "iptemp-email-body-text", "nonce" => "iptemp_email_notifications"),
//                    "iptemp-email-notifications3" => array("name" => "iptemp-button-text", "nonce" => "iptemp_email_notifications"),
            "iptemp-user-reviews" => array("name" => "iptemp-main-quote", "nonce" => "iptemp_user_reviews"),
            "iptemp-user-reviews2" => array("name" => "iptemp-body-quote", "nonce" => "iptemp_user_reviews"),
            "iptemp-user-reviews3" => array("name" => "iptemp-user-review-name", "nonce" => "iptemp_user_reviews"),
            "iptemp-user-reviews4" => array("name" => "iptemp-user-review-url-text", "nonce" => "iptemp_user_reviews"),
            "iptemp-user-reviews5" => array("name" => "iptemp-user-review-url", "nonce" => "iptemp_user_reviews"),
            "iptemp-user-reviews6" => array("name" => "iptemp-user-reviews-title", "nonce" => "iptemp_user_reviews"),
            "iptemp-about-us" => array("name" => "iptemp-team-member-name", "nonce" => "iptemp_about_us"),
            "iptemp-about-us2" => array("name" => "iptemp-team-member-bio", "nonce" => "iptemp_about_us"),
            "iptemp-about-us3" => array("name" => "iptemp-team-member-picture", "nonce" => "iptemp_about_us"),
            "iptemp-about-us4" => array("name" => "iptemp-about-us-title", "nonce" => "iptemp_about_us"),
            "iptemp-about-us5" => array("name" => "iptemp-company-bio", "nonce" => "iptemp_about_us"),
            "iptemp-other-apps" => array("name" => "iptemp-app-name", "nonce" => "iptemp_other_apps"),
            "iptemp-other-apps2" => array("name" => "iptemp-app-url", "nonce" => "iptemp_other_apps"),
            "iptemp-other-apps3" => array("name" => "iptemp-app-icon-url", "nonce" => "iptemp_other_apps"),
            "iptemp-price-and-url" => array("name" => "iptemp-app-price", "nonce" => "iptemp_price_and_url"),
            "iptemp-price-and-url2" => array("name" => "iptemp-app-itunes-url", "nonce" => "iptemp_price_and_url"),
            "iptemp-contact-form" => array("name" => "iptemp-contact-form-email", "nonce" => "iptemp_contact_form"),
            "iptemp-screenshots-popup" => array("name" => "iptemp-image-url", "nonce" => "iptemp_screenshots_popup"),
            "iptemp-screenshots-popup2" => array("name" => "iptemp-image-description", "nonce" => "iptemp_screenshots_popup"),
            "iptemp-color-scheme" => array("name" => "iptemp-color-scheme-name", "nonce" => "iptemp_color_scheme")
        );        

        foreach($new_meta_boxes as $meta_box) {

            /* Verify the nonce before proceeding. */
            if ( !isset( $_POST[$meta_box['nonce'] . '_nonce'] ) || !wp_verify_nonce( $_POST[$meta_box['nonce'] . '_nonce'], basename( __FILE__ ) ) )
                    return $post_id;

            /* Get the post type object. */
            $post_type = get_post_type_object( $post->post_type );

            /* Check if the current user has permission to edit the post. */
            if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
                    return $post_id;

            /* Get the posted data and sanitize it for use as an HTML class. */
            //$new_meta_value = ( isset( $_POST['smashing-post-class'] ) ? sanitize_html_class( $_POST['smashing-post-class'] ) : '' );
            $new_meta_value = $_POST[$meta_box['name']];

            /* Get the meta key. */
            $meta_key = $meta_box['name'];

            /* Get the meta value of the custom field key. */
            $meta_value = get_post_meta( $post_id, $meta_key, true );

            /* If a new meta value was added and there was no previous value, add it. */
            if ( $new_meta_value && '' == $meta_value )
                    add_post_meta( $post_id, $meta_key, $new_meta_value, true );

            /* If the new meta value does not match the old value, update it. */
            elseif ( $new_meta_value && $new_meta_value != $meta_value )
                    update_post_meta( $post_id, $meta_key, $new_meta_value );

            /* If there is no new meta value but an old value exists, delete it. */
            elseif ( '' == $new_meta_value && $meta_value )
                    delete_post_meta( $post_id, $meta_key, $meta_value );
        }
}

