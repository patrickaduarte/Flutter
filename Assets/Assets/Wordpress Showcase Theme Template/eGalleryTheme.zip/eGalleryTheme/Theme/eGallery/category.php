﻿<?php get_header(); ?>	

<div id="container">
	
<div id="left-div">
		
<div id="left-inside">

<span class="current-category">
<?php single_cat_title('Currently Browsing: ', 'display'); ?>
</span>


<!--Begind recent post (single)-->
<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<div class="home-post-wrap">	

<div class="thumbnail-div" style="background-image: url(<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=159&amp;w=190&amp;zc=1);">
<div class="info">
<span class="info-titles"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '18') ?></a></span>
<?php the_content_limit(140, ""); ?>
</div>
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/slider-button.png" alt="more info" class="info-button" />
</div>	

<div class="bar">
<div class="ratingbox">
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/delete.png" alt="delete" class="delete" />
<div style="clear: both;"></div>
<?php if(function_exists('the_ratings')) { the_ratings(); } ?>  
</div>
<a href="#" class="rating" style="float: left;" title="Click here to rate this post"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/star.gif" alt="rate this post" style="border: none;" /></a>
<div class="comments-bubble"><?php comments_popup_link('0', '1', '% '); ?></div>
<a href="#" class="rating" style="float: left; cursor: pointer; margin-left: 9px;" title="This article was posted on: <?php the_time('m jS, Y') ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/date.gif" alt="date" style="border: none;" /></a>
<a href="<?php the_permalink() ?>" style="float: right;" title="Click here to read the rest of: <?php the_title2('', '...', true, '30') ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/read-more.gif" style="border: none;" alt="read more" /></a>
</div>

</div>

<?php endwhile; ?>
<!--end recent post (single)-->

<div style="clear: both;"></div>

<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
else { ?>
<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>
<?php } ?>

<?php else : ?>

<h2 >No Results Found</h2>

<p>Sorry, your search returned zero results. </p>

<?php endif; ?>
	
</div>
		
</div>

<?php get_sidebar(); ?>    
<?php get_footer(); ?>   

</body>
</html>