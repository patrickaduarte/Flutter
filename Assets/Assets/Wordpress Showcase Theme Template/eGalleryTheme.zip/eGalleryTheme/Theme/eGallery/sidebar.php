<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
<div id="sidebar">

		
<!--Featured Articles-->
<div class="sidebar-box2">
<h3>featured articles</h3>
<ul class="menu">
<?php $my_query = new WP_Query("category_name=Featured Articles&showposts=6");
while ($my_query->have_posts()) : $my_query->the_post(); ?>
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<li>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=53&amp;w=53&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" style="opacity:0.5;filter:alpha(opacity=50); border: none;" onmouseover="this.style.opacity=1;this.filters.alpha.opacity=100"
onmouseout="this.style.opacity=0.5;this.filters.alpha.opacity=50"  /></a>
<em>
<img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=120&amp;w=207&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  class="featured-hover" />
</em>
</li>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<?php endwhile; ?>
</ul>
</div>
<!--End Featured Articles-->

<!--Begin Random Articles-->
<div class="sidebar-box2">
<h3>random articles</h3>
<ul class="menu">
<?php $my_query = new WP_Query('orderby=rand&showposts=6');
while ($my_query->have_posts()) : $my_query->the_post();
?>
<li>
<a href="<?php the_permalink() ?>"><img style="opacity:0.5;filter:alpha(opacity=50); border: none;" alt="random article" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo get_post_meta($post->ID, "Thumbnail", true); ?>&amp;h=53&amp;w=53&amp;zc=1" onmouseover="this.style.opacity=1;this.filters.alpha.opacity=100"
onmouseout="this.style.opacity=0.5;this.filters.alpha.opacity=50" /></a>
<em>
<img alt="random article" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo get_post_meta($post->ID, "Thumbnail", true); ?>&amp;h=120&amp;w=207&amp;zc=1" style="border-left: 1px solid #242F39; border-top: 1px solid #242F39; border-bottom: 1px solid #4A5865; border-right: 1px solid #4A5865;" />
</em>
</li>
<?php endwhile; ?>
</ul>
</div>
<!--End Random Articles-->	

<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar() ) : ?>  
	       
<div class="sidebar-box">
<h3>Categories</h3>
<ul>
<?php wp_list_cats('sort_column=name&hierarchical=0'); ?>
</ul>
</div>



<?php endif; ?>
                
</div>
            
</div>
