$(document).ready(function(){

	$(".thumbnail-div .info-button").click(function(){
	  $(this).prev(".info").slideToggle("slow");
		$(this).toggleClass("active"); return false;
	});


	$(".bar .rating").click(function(){
	  $(this).prev(".ratingbox").slideToggle("slow");
		$(this).toggleClass("active"); return false;
	});
	
	$(".post-wrapper .lightboxclick").click(function(){
	  $(this).prev(".lightbox").slideToggle("slow");
		$(this).toggleClass("active"); return false;
	});

});
$(document).ready(function(){

	$(".ratingbox .delete").click(function(){
	  $(this).parents(".ratingbox").animate({ opacity: "hide" }, "slow");
	});

});
$(document).ready(function(){

	$(".lightbox .lightboxdelete").click(function(){
	  $(this).parents(".lightbox").animate({ opacity: "hide" }, "slow");
	});

});
	var query = new Object();
	window.location.search.replace(
	new RegExp( "([^?=&]+)(=([^&]*))?", 'g' ),
		function( $0, $1, $2, $3 ){
			query[ $1 ] = $3;
		}
	);
	easing = query['e'] || 'Circ';
	
	function loadEasing(e) {
		location.href = location.pathname+'?e='+e;
	}
	
	function setEasing(e) {
		loadLamps(e);
	}

// for dynamic easing changes		
	function loadLamps(easing) {
		$('#lavaLampBasicImage').lavaLamp({
			fx: 'easeIn'+easing,
			speed: 800
		});

		$('#lavaLampVariableImage').lavaLamp({
			fx: 'easeOut'+easing,
			speed: 800,
			linum: 0
		});

	}
	
// jquery initialize:
	$(function() {
		loadLamps(easing);
		
		$('select#easing option[value='+easing+']').attr('selected','selected');
		$('.easingLabel').text(easing);
	});
	
// hover preview
$(document).ready(function(){

	$(".menu a").hover(function() {
		$(this).next("em").animate({opacity: "show", top: "-170"}, "slow");
	}, function() {
		$(this).next("em").animate({opacity: "hide", top: "-180"}, "fast");
	});


});
$(document).ready(function(){

	$(".login").click(function(){
		$(".login-div").slideToggle("slow");
		$(this).toggleClass("active"); return false;
	});
	
	 
});
