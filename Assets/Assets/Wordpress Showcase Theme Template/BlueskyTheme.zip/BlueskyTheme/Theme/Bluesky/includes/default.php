<?php get_header(); ?>	

<div id="wrapper">
	
<div id="content-wrapper">
		
<div id="content">
			
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

<?php $thumb = get_post_meta($post->ID, 'Thumbnail', $single = true); ?>

<div class="post-wrapper">		
<div style="float: left; margin-left: -71px;" class="ie6float">
<div class="date">
<span class="month"><?php the_time('M') ?></span>
<span class="day"><?php the_time('j') ?></span>
</div>
<div style="float: left; width: 570px; clear: right; margin-top: 3px; margin-bottom: 0px; padding-top: 10px;  margin-left: 5px;" class="iehack">
<h2 class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="articleinfo"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icon1.gif" alt="icon1" /> Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>
<div style="clear: both;"></div>	
</div>
</div>
<div style="clear: both;"></div>
<div class="post">
<div class="homepost-left">
<div class="thumbnailwrap">
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=94&amp;w=94&amp;zc=1" class="thumbnail-home" width="94px" height="94px" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"	/>
<?php } else { echo ''; } ?>
</div>
<?php Show_Dropdown(); ?>
</div>		
<div class="homepost-right">
<?php the_content_limit(560, ""); ?>
</div>
</div>
</div>

<?php endwhile; ?>

<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>

<?php else : ?>

<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
<?php endif; ?>
		
</div>
		
</div>

		<?php get_sidebar(); ?>    
		<?php get_footer(); ?>   
	
</body>
</html>