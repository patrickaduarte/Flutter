<div id="footer">
Powered by <a href="http://www.wordpress.org">Wordpress</a> | Designed by <a href="http://www.elegantthemes.com">Elegant Themes</a>
</div>
</div>
</div>
</div>

<?php wp_footer(); ?>