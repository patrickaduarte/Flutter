<?php
function Dropdown_CheckIntegrity() {
//There's nothing here, the existance of this function tells it all
}
?>