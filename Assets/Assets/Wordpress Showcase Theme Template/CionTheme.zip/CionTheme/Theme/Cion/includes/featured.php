<!--Begind Feautred Articles-->
<div style="clear: both;"></div>
<?php $my_query = new WP_Query("category_name=Featured Articles&showposts=$artsee_homepage_featured");
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<div class="featured-item">
<a href="<?php the_permalink() ?>" class="featured-thumb"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=160&amp;w=183&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  class="featured-thumb-img" /></a>
<div class="featured-info">
<span class="featured-title"><?php the_title2('', '...', true, '30') ?></span>
<div style="clear: both;"></div>
Posted by <?php the_author() ?>  on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?>
</div>
</div>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<?php endwhile; ?>  
<div style="clear: both;"></div>
<!--End Feautred Articles-->