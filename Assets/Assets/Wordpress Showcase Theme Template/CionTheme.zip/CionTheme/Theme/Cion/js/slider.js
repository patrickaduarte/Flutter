$(document).ready(function(){

	$(".featured-item").hover(function() {
		$(this).children(".featured-info").animate({opacity: "show"}, "slow");
	}, function() {
		$(this).children(".featured-info").animate({opacity: "hide"}, "fast");
	});
	

		$(".search-slide-button").click(function(){
	  $(this).next(".search-slide").animate({opacity: "show"}, "slow");
	});
	
		$(".search-slide .delete").click(function(){
	  $(this).parent("div").animate({ opacity: "hide" }, "slow");
	});

});
$(document).ready(function(){

	$(".home-post-wrap2 .share").click(function(){
	  $(this).next("div").slideToggle("slow");
		$(this).toggleClass("active"); return false;
	});

});