<?php get_header(); ?>	

<div id="container">
<div id="left-div">

<span class="current-category">
<?php single_cat_title('Currently Browsing: ', 'display'); ?>
</span>

<!--Begind recent post (single)-->
<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>
<div class="home-post-wrap2">	
<h2 class="titles"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="post-info">Posted by <?php the_author() ?>  on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>
<div style="clear: both;"></div>
<?php the_content(); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>
<?php endwhile; ?>
<!--end recent post (single)-->

<div style="clear: both;"></div>

<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
else { ?>
<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>
<?php } ?>

<?php else : ?>

<!--If no results are found-->
<div class="home-post-wrap2">
<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
</div>
<!--End if no results are found-->

<?php endif; ?>

	
</div>

<?php get_sidebar(); ?>    
<?php get_footer(); ?>   
	
</body>
</html>