<?php get_header(); ?>	
<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
<?php if (get_option('artsee_featured') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/featured.php'); } ?>
<!--Begin About Us Section-->
<div class="about">
<div class="about-div">
<img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $artsee_about_image; ?>&amp;h=90&amp;w=90&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  style="border: none;" />
</div>
<span class="h3-titles">About Me</span>
<?php echo $artsee_about; ?>
</div>
<!--End About Us Section-->

<!--Begin Sidebar Tabbed Menu-->
<div class="about">
<ul class="idTabs">
<li><a href="#recententries">Recent</a></li>
<li><a href="#recentcomments2">Comments</a></li>
<li><a href="#randomarticles">Random</a></li>
<li><a href="#populararticles">Popular</a></li>
</ul>
<div style="clear: both;"></div>
<div id="recententries">
<ul>
 <?php $my_query = new WP_Query('showposts=5');
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '50') ?></a></li>
<?php endwhile; ?>
</ul>
</div>
<div id="recentcomments2">
<?php include (TEMPLATEPATH . '/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */ ?>
<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments("5", 40, '', ''); } ?>
</div>
<div id="randomarticles">
<ul>
 <?php $my_query = new WP_Query('orderby=rand&showposts=5');
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '50') ?></a></li>
<?php endwhile; ?>
</ul>
</div>

<div id="populararticles">
<ul>
<?php
	$sql='SELECT post_title, comment_count, guid
		FROM wp_posts
		ORDER BY comment_count DESC
		LIMIT 5;';
	$results = $wpdb->get_results($sql);

	foreach ($results as $r) {
		echo '<li><a href="' . $r->guid . '" title="' . $r->post_title . '"> ' . $r->post_title .
			' (' . $r->comment_count . ')</a></li>';
	}
?>
</ul>
</div>

</div>
<!--End Sidebar Tabbed Menu-->

<div id="container">
<div id="left-div">
<!--Begind recent post (single)-->
<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>
<div class="home-post-wrap2">	
<h2 class="titles"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="post-info">Posted by <?php the_author() ?>  on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>
<div style="clear: both;"></div>
<?php the_content(); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>
<?php endwhile; ?>
<!--end recent post (single)-->

<div style="clear: both;"></div>

<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
else { ?>
<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>
<?php } ?>

<?php else : ?>

<!--If no results are found-->
<div class="home-post-wrap2">
<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
</div>
<!--End if no results are found-->

<?php endif; ?>

	
</div>

<?php get_sidebar(); ?>    
<?php get_footer(); ?>   
	
</body>
</html>