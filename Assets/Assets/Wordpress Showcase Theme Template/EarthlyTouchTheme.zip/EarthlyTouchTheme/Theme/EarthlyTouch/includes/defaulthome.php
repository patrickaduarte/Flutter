<div id="container">

<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>
	
<div id="left-div">
		
<div id="left-inside">
<?php if (get_option('artsee_featured') == 'Disable') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/featured.php'); } ?>

<!--Begin Recent Comments-->	
<div class="home-squares">
<div class="home-headings">Recent Comments</div>
<div class="recent-comments">
<?php include (TEMPLATEPATH . '/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */?>
<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(6, 60, '', ''); } ?>
</div>
</div>
<!--End Recent Comments-->	

<!--Begin Random Articles-->	
<div class="home-squares">
<div class="home-headings">Random Articles</div>
<?php $my_query = new WP_Query('orderby=rand&showposts=3');
while ($my_query->have_posts()) : $my_query->the_post();
?>
<div class="random">
<?php $thumb = get_post_meta($post->ID, 'Thumbnail', $single = true); ?>
<?php if($thumb !== '') { ?>
<div class="random-image">
<a href="<?php the_permalink() ?>"><img height="80px" width="70px" style="border: none;" alt="random article" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=80&amp;w=70&amp;zc=1&amp;q=100" /></a>
</div>
<?php } else { echo ''; } ?>

<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '25') ?></a>
<?php the_content_limit(80, ""); ?>
</div>
<?php endwhile; ?>
</div>
<!--End Random Articles-->	
			
<?php if (have_posts()) : while (have_posts()) : the_post(); 
if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<!--Begin Post Limit-->				
<?php static $ctr = 0; 
if ($ctr == "$artsee_homepage_posts;") { break; } 
else { ?>
<!--End Post Limit-->		

<!--Begin Articles Single-->	
<div class="home-post-wrap">
<div class="entry">
<?php $thumb = get_post_meta($post->ID, 'Thumbnail', $single = true); ?>
<?php if($thumb !== '') { ?>
<div class="thumbnail-div" style="margin-bottom: 10px;">
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=150&amp;w=90&amp;zc=1&amp;q=100" width="90px" style="border: none;" height="150px" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" /></a>
</div>
<?php } else { echo ''; } ?>
<div class="post-content">
<h2 class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '50') ?></a></h2>
<?php the_content_limit(420, ""); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>
</div>	
</div>
<!--End Articles Single-->	

<?php $ctr++; } ?>


<?php endwhile; ?>

<?php else : ?>

<!--If no results are found-->
<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
<!--End if no results are found-->

<?php endif; ?>
			
</div>
		
</div>

<!--Begin Sidebar-->
<?php get_sidebar(); ?>    
<!--End Sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>   
<!--End Footer-->
	
</body>
</html>