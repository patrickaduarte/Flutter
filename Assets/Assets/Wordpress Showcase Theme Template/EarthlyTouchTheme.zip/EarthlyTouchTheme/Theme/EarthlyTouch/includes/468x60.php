﻿<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>
<a href="<?php echo $artsee_banner_468_url; ?>"><img src="<?php echo $artsee_banner_468; ?>" alt="banner ad" style="float: left; margin-left: 50px; border: none;" /></a>
<div style="clear: both;"></div>