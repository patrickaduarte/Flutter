﻿<div id="container">
	
<div id="left-div">
		
<div id="left-inside">
			
<?php if (have_posts()) : while (have_posts()) : the_post(); 
if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>
<!--Begin Article Single-->	 
<div class="home-post-wrap">
<div class="entry">
<h1 class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '50') ?></a></h1>
<div class="articleinfo">Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('F j, Y') ?> | <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>
<?php the_content(); ?>
</div>	
</div>
<!--End Article Single-->	 

<?php endwhile; ?>

<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>

<?php else : ?>

<!--If no results are found--> 
<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
<!--End if no results are found--> 

<?php endif; ?>
			
</div>
		
</div>

<!--Begin sidebar-->
<?php get_sidebar(); ?>    
<!--End sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>   
<!--End Footer-->

</body>
</html>