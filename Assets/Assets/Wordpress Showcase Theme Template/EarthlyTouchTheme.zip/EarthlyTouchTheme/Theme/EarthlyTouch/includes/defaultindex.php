﻿<div id="container">
	
<div id="left-div">
		
<div id="left-inside">
			
<?php if (have_posts()) : while (have_posts()) : the_post(); 
if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<?php 
		// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
				 ?>

<!--Begin Article Single-->	 
<div class="home-post-wrap">
<div class="entry">
<div class="thumbnail-div" style="margin-bottom: 10px;">
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=150&amp;w=90&amp;zc=1&amp;q=100" width="90px" style="border: none;" height="150px" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" /></a>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
</div>
<div class="post-content">
<h2 class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '50') ?></a></h2>
<?php the_content_limit(420, ""); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>
</div>	
</div>
<!--End Article Single-->	 

<?php endwhile; ?>

<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>

<?php else : ?>

<!--If no results are found--> 
<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
<!--End if no results are found--> 

<?php endif; ?>
			
</div>
		
</div>

<!--Begin sidebar-->
<?php get_sidebar(); ?>    
<!--End sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>   
<!--End Footer-->

</body>
</html>