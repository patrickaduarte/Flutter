﻿<div id="featured">
<?php $my_query = new WP_Query('category_name=Featured Articles&showposts=1');
while ($my_query->have_posts()) : $my_query->the_post();
$do_not_duplicate = $post->ID; ?>
<div class="thumbnail-div-featured">
<a href="<?php the_permalink() ?>"><img height="200px" width="200px" style="border: none;" alt="featured article" src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo get_post_meta($post->ID, "Thumbnail", true); ?>&amp;h=200&amp;w=200&amp;zc=1&amp;q=100" /></a>
</div>
<div class="featured-content">
<span class="titles-featured"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></span>
<?php the_content_limit(500, ""); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>
<div style="clear: both;"></div>
<?php endwhile; ?>
</div>