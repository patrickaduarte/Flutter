﻿<?php get_header(); ?>	

<div id="container">
	
<div id="left-div">
		
<div id="left-inside">
			
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

<!--Begin Article Single-->
<div class="post-wrapper">
<h1 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h1>
<div class="page-post">
<?php the_content('Read the rest of this entry &raquo;'); ?>
</div>
</div>
<!--End Article Single-->

<?php endwhile; ?>

<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>

<?php else : ?>

<!--If no results are found--> 
<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
<!--End if no results are found--> 

<?php endif; ?>
			
</div>
		
</div>

<!--Begin sidebar-->
<?php get_sidebar(); ?>    
<!--End sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>   
<!--End Footer-->
	
</body>
</html>