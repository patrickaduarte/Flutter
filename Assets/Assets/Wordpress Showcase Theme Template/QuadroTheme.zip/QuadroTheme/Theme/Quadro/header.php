<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php if (is_home()) : ?><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?>
<?php else : ?>
<?php wp_title('', 'false'); ?> - <?php bloginfo('name'); ?>
<?php endif; ?></title>

 <meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->

<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style<?php echo $artsee_color; ?>.css" type="text/css" media="screen" />
	<!--[if IE 7]>	
		<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/iestyle.css" />
	<![endif]-->	
	
	<!--[if lt IE 7]>
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/ie6style.css" />
	<![endif]-->
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />

<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />

<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />

<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/idtabs.js"></script>
<?php wp_get_archives('type=monthly&format=link'); ?>
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
</head>

<body>

	<div id="pages">
		 			 <ul>
              		<li class="page_item"><a href="<?php bloginfo('url'); ?>">Home</a></li>

	<?php wp_list_pages("sort_order=$artsee_order_page&exclude=$artsee_exclude_page&depth=1&title_li="); ?>
	
                </ul>
	</div>
	
<div style="clear: both;"></div>
<div id="header">
<a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/logo.gif" alt="logo" class="logo" /></a>
<div class="search_bg">
<div id="search">
<form method="get" action="<?php bloginfo('home'); ?>" style="padding:0px 0px 0px 0px; margin:0px 0px 0px 0px">
<input type="text"  name="s" value="<?php echo wp_specialchars($s, 1); ?>"/><input type="image" class="input" src="<?php bloginfo('stylesheet_directory'); ?>/images/search-<?php echo $artsee_color; ?>.gif" value="submit"/>
					</form>
</div>
</div>
</div>
<div style="clear: both;"></div>
	<div id="wrapper2">
<div id="categories">
<ul>
<?php wp_list_cats("sort_column=$artsee_sort_cat&sort_order=$artsee_order_cat&exclude=$artsee_exclude_cat&optioncount=0&depth=1"); ?>
</ul>
<div style="clear: both;"></div>
</div>
<div style="clear: both;"></div>