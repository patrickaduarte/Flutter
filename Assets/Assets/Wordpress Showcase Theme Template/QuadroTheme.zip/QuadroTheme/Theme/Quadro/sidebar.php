<div id="sidebar-wrapper">       
<div id="sidebar">

<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>

<!--Begin 250x250 Ad Block-->
<?php if (get_option('artsee_twofifty') == 'Enable') { ?>
<?php include(TEMPLATEPATH . '/includes/250x250.php'); ?>
<?php } else { echo ''; } ?>
<!--End 250x250 Ad Block-->

<!--Begin 125x125 Ad Block-->
<?php if (get_option('artsee_ads') == 'Disable') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/ads.php'); } ?>
<!--End 125x125 Ad Block-->
			
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>                 
              
<div class="sidebar-box">
<h2>Archives</h2>
<ul>
<?php wp_get_archives('type=monthly'); ?>
</ul>
</div>

<div class="sidebar-box">
<h2>Categories</h2>
<ul>
<?php wp_list_categories('show_count=0&title_li='); ?>
</ul>
</div>

<div class="sidebar-box">           
<h2>Blogroll</h2>
<ul>
<?php get_links(-1, '<li>', '</li>', ''); ?>
</ul> 
</div>

<div class="sidebar-box">
<h2>Search</h2>
<div style="margin-left: 20px;">
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</div>
</div>

<div class="sidebar-box">   
<h2>Meta</h2>
<ul>
<?php wp_register(); ?>
<li><?php wp_loginout(); ?></li>
<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
<?php wp_meta(); ?>
</ul>
</div>

<?php endif; ?>
                
</div>
</div>
</div>