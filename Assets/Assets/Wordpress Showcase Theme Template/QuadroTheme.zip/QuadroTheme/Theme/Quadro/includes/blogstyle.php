﻿<div id="wrapper">
<div id="content-wrapper">
<div id="content">
		
 <?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

			
<div class="post-wrapper" style="margin-bottom: 20px;">

			<h2 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
			<div class="articleinfo"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icon1.gif" alt="icon1" /> Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('M jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>

			<div class="post">

			<?php the_content('Read the rest of this entry &raquo;'); ?>

			</div>
</div>
			<?php endwhile; ?>
<div style="clear: both;"></div>
			   <p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>

			<?php else : ?>

			<h2 >No Results Found</h2>

			<p>Sorry, your search returned zero results. </p>

			<?php endif; ?>
			
			
	
			</div>
		
		</div>
		<?php get_sidebar(); ?>    
		<?php get_footer(); ?>   

</body>
</html>