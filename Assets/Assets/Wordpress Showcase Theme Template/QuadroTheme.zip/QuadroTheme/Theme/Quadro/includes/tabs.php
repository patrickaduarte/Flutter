﻿<ul class="idTabs">
<li><a class="" href="#recententries">Recent Entries</a></li>
<li><a class="" href="#recentcomments2">Recent Comments</a></li>
<li><a class="" href="#mostcomments">Popular Posts</a></li>
</ul>

<div id="recententries">
<span class="toptitle">Recent Posts</span>
<ul class="list2">
<?php get_archives('postbypost', 8); ?>
</ul>
</div>

<div id="recentcomments2">
<span class="toptitle">Recent Comments</span>
<?php include (TEMPLATEPATH . '/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */?>
<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(5, 60, '', ''); } ?>
</div>


<div id="mostcomments">
<span class="toptitle">Popular Articles</span>
<ul class="list2">
<?php
	$sql='SELECT post_title, comment_count, guid
		FROM wp_posts
		ORDER BY comment_count DESC
		LIMIT 5;';
	$results = $wpdb->get_results($sql);

	foreach ($results as $r) {
		echo '<li><a href="' . $r->guid . '" title="' . $r->post_title . '"> ' . $r->post_title .
			' (' . $r->comment_count . ')</a></li>';
	}
?>
</ul>
</div>