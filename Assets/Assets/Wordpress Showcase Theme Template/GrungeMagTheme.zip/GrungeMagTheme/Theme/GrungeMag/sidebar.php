<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>

<div id="sidebar">

<!--Begin Sidebar Tabbed Menu-->
<ul class="idTabs">
<li><a href="#recententries">Recent Entries</a></li>
<li><a href="#recentcomments2">Recent Comments</a></li>
<li><a href="#mostcomments">About Us</a></li>
</ul>
<div id="recententries" class="sidebar-box">
<ul >
<?php get_archives('postbypost', "$artsee_tab_entries;"); ?>
</ul>
</div>
<div id="recentcomments2" class="sidebar-box">
<?php include (TEMPLATEPATH . '/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */ ?>
<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments("$artsee_tab_comments;", 85, '', ''); } ?>
</div>
<div id="mostcomments" class="sidebar-box">
<?php echo $artsee_about; ?>
</div>
<!--End Sidebar Tabbed Menu-->

<?php if (get_option('artsee_ads') == 'Enable') { ?>
<?php include(TEMPLATEPATH . '/includes/ads.php'); ?>
<?php } else { echo ''; } ?>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?> 
		       
<div class="sidebar-box">
<h2>Archives</h2>
<ul>
<?php wp_get_archives('type=monthly'); ?>
</ul>
</div>

<div class="sidebar-box">
<h2>Categories</h2>
<ul>
<?php wp_list_categories('show_count=0&title_li='); ?>
</ul>
</div>

<div class="sidebar-box">           
<h2>Blogroll</h2>
<ul>
<?php get_links(-1, '<li>', '</li>', ''); ?>
</ul> 
</div>

<div class="sidebar-box">
<h2>Search</h2>
<div style="margin-left: 20px;">
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</div>
</div>

<div class="sidebar-box">   
<h2>Meta</h2>
<ul>
<?php wp_register(); ?>
<li><?php wp_loginout(); ?></li>
<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
<?php wp_meta(); ?>
</ul>
</div>

<?php endif; ?>
                
</div>
            
</div>
