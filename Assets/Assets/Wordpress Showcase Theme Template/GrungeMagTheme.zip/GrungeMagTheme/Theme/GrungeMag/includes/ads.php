﻿<div class="sidebar-box" style="padding-left: 25px; width: 265px;">
<a href="<?php echo $artsee_banner_url_one; ?>"><img src="<?php echo $artsee_banner_image_one; ?>" style="border: none;" alt="advertisement" /></a>
<a href="<?php echo $artsee_banner_url_two; ?>"><img src="<?php echo $artsee_banner_image_two; ?>" style="border: none;" alt="advertisement" /></a>
<a href="<?php echo $artsee_banner_url_three; ?>"><img src="<?php echo $artsee_banner_image_three; ?>" style="border: none;" alt="advertisement" /></a>
<a href="<?php echo $artsee_banner_url_four; ?>"><img src="<?php echo $artsee_banner_image_four; ?>" style="border: none;" alt="advertisement" /></a>
</div>