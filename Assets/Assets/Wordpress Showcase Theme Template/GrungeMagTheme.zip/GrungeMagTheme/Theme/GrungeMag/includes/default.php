﻿<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
	  
<!--Begin Scroller Articles-->
<div id="slide">
<script type="text/javascript" >
	$(function() {
		$("#scrollable").scrollable({horizontal:true,size: 5});
	});
</script>
<div id="scrollable"> 

<a class="prev"></a> 
  
<div class="items"> 
<?php $my_query = new WP_Query('showposts=11');
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<div class="slide-items">
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=123&amp;w=155&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  style="border: none;" /></a>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<span class="slide-items-a"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '12') ?></a></span>
</div>
<?php endwhile; ?>  
<div style="clear: both;"></div>
</div> 
<a class="next"></a>   
<div style="clear: both;"></div>
</div>
<!--End Scroller-->

</div>

<div id="container">
	
<div id="left-div">
		
<div id="left-inside">

<div class="home-post-wrap-home">

<!--Begin Feaured Articles-->
<span class="headings">featured articles</span>
<div style="clear: both;"></div>
<?php $my_query = new WP_Query("category_name=Featured Articles&showposts=$artsee_featured;");
while ($my_query->have_posts()) : $my_query->the_post(); ?>
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<div class="random">
<div class="random-image">
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=80&amp;w=80&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  style="border: none;" /></a>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
</div>
<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '23') ?></a>
<?php if (function_exists('the_content_limit')) { the_content_limit(80, ""); } else { echo 'You have not uploaded and acivated the limit posts plugin. This is required.'; } ?>
</div>
<?php endwhile; ?>
<!--End Feaured Article-->
</div>

<div class="home-post-wrap-home">	
<!--Begin Most Commented Articles-->
<span class="headings">popular articles</span>
<div style="clear: both;"></div>
<ul>
<?php
	$sql='SELECT post_title, comment_count, guid
		FROM wp_posts
		ORDER BY comment_count DESC
		LIMIT 6;';
	$results = $wpdb->get_results($sql);

	foreach ($results as $r) {
		echo '<li><a href="' . $r->guid . '" title="' . $r->post_title . '"> ' . $r->post_title .
			' (' . $r->comment_count . ')</a></li>';
	}
?>
</ul>
<!--End Most Commented Articles-->

<!--Begin Random Articles-->
<span class="headings">random articles</span>
<div style="clear: both;"></div>
<ul>
<?php $my_query = new WP_Query("orderby=rand&showposts=$artsee_random;");
while ($my_query->have_posts()) : $my_query->the_post();
?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '40') ?></a></li>
<?php endwhile; ?>
</ul>
<!--End Random Articles-->
</div>

<div style="clear: both;"></div>

<!--The following code controls the category boxes-->

<!--Category Box 1-->
<?php $my_query = new WP_Query("cat=$artsee_home_cat_one;&showposts=1");
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<div class="home-post-wrap-box">
<span class="headings">recent from <?php echo $artsee_cat_one_name; ?></span>
<span class="titles-boxes"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
<div style="clear: both;"></div>
<!--Display thumbnail if found-->
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<div class="cat-thumb">
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=100&amp;w=100&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" style="border: none;" /></a>
</div>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<!--End display thumbnail if found-->
<?php the_content_limit(300, ""); ?>
<div style="clear:both;"></div>	
</div>
<?php endwhile; ?>
<!--End Category Box 1-->	
		
<!--Category Box 2-->
<?php $my_query = new WP_Query("cat=$artsee_home_cat_two;&showposts=1");
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<div class="home-post-wrap-box">
<span class="headings">recent from <?php echo $artsee_cat_two_name; ?></span>
<span class="titles-boxes"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
<div style="clear: both;"></div>
<!--Display thumbnail if found-->
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<div class="cat-thumb">
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>//timthumb.php?src=<?php echo $thumb; ?>&amp;h=100&amp;w=100&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" style="border: none;" /></a>
</div>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<!--End display thumbnail if found-->
<?php the_content_limit(300, ""); ?>
<div style="clear:both;"></div>	
</div>
<?php endwhile; ?>
<!--End Category Box 2-->

<div style="clear: both;"></div>

<!--Category Box 3-->
<?php $my_query = new WP_Query("cat=$artsee_home_cat_three;&showposts=1");
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<div class="home-post-wrap-box">
<span class="headings">recent from <?php echo $artsee_cat_three_name; ?></span>
<span class="titles-boxes"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
<div style="clear: both;"></div>
<!--Display thumbnail if found-->
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<div class="cat-thumb">
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=100&amp;w=100&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" style="border: none;" /></a>
</div>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<!--End display thumbnail if found-->
<?php the_content_limit(300, ""); ?>
<div style="clear:both;"></div>	
</div>
<?php endwhile; ?>
<!--Category Box 3-->

<!--Category Box 4-->
<?php $my_query = new WP_Query("cat=$artsee_home_cat_four;&showposts=1");
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<div class="home-post-wrap-box">
<span class="headings">recent from <?php echo $artsee_cat_four_name; ?></span>
<span class="titles-boxes"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
<div style="clear: both;"></div>
<!--Display thumbnail if found-->
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<div class="cat-thumb">
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=100&amp;w=100&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" style="border: none;" /></a>
</div>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<!--End display thumbnail if found-->
<?php the_content_limit(300, ""); ?>
<div style="clear:both;"></div>	
</div>
<?php endwhile; ?>
<!--Category Box 4-->

<!--End category boxes-->

<div style="clear: both;"></div>

<!--Begin recent post (single)-->
<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<?php static $ctr = 0; 
if ($ctr == "$artsee_homepage_posts;") { break; } 
else { ?>

<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
?>
<div class="home-post-wrap2">	
<div class="post-info">Posted by <?php the_author() ?>  on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>
<div style="clear: both;"></div>
<h2 class="titles"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div style="clear: both;"></div>
<!--Display thumbnail if found-->
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<div class="thumbnail-div-home">
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=130&amp;w=281&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  style="border: none;" /></a>
</div>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<!--End display thumbnail if found-->
<?php if (function_exists('the_content_limit')) { the_content_limit(400, ""); } else { echo 'You have not uploaded and acivated the limit posts plugin. This is required.'; } ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>

<?php $ctr++; } ?>

<?php endwhile; ?>
<!--end recent post (single)-->



<?php else : ?>

<!--If no results are found-->
<div class="home-post-wrap2">
<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
</div>
<!--End if no results are found-->

<?php endif; ?>

</div>
		
</div>

<?php get_sidebar(); ?>    
<?php get_footer(); ?>   
	
</body>
</html>