<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php if (is_home()) : ?><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?>
<?php else : ?>
<?php wp_title('', 'false'); ?> - <?php bloginfo('name'); ?>
<?php endif; ?></title>

 <meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
	<!--[if IE 7]>	
		<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/iestyle.css" />
	<![endif]-->	
	
	<!--[if lt IE 7]>
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/ie6style.css" />
	<![endif]-->
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />

<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />

<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />

<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<?php wp_get_archives('type=monthly&format=link'); ?>
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/idtabs.js"></script>

</head>

<body>
<div id="wrapper2">
<div id="header-top"></div>
<div id="header">

<div id="header-left">
<a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/logo.gif" alt="logo" style="border: none;" /></a>
<div class="search_bg">
<div id="search">
<form method="get" action="<?php bloginfo('home'); ?>" style="padding:0px 0px 0px 0px; margin:0px 0px 0px 0px">
<input type="text"  name="s" value="<?php echo wp_specialchars($s, 1); ?>"/><input type="image" class="input" src="<?php bloginfo('stylesheet_directory'); ?>/images/search.gif" value="submit"/>
					</form>
</div>
</div>
</div>

	  <div id="header-right">
	  <?php include 'adsense/468x60.php';?>
	  </div>

			<div style="clear: both;"></div>
	<img src="<?php bloginfo('stylesheet_directory'); ?>/images/nav-left.gif" alt="nav-left" class="nav-image"  style="margin-left: 10px;" />
	<div id="pages">
		 	 <ul>     
              		<li class="page_item">
					
					<a href="<?php bloginfo('url'); ?>" style="float: left;">Home</a>
					
					</li>

	<?php wp_list_pages('depth=1&title_li='); ?>
	
                </ul>
	</div>
		<img src="<?php bloginfo('stylesheet_directory'); ?>/images/nav-right.gif" class="nav-image" alt="nav-left" />
		
		<div id="recent">
<div id="recent-left">

<ul class="idTabs">
<li><a href="#recententries">Entries</a></li>
<li><a href="#recentcomments2">Comment</a></li>
<li><a href="#mostcomments">Popular</a></li>
</ul>

<div id="recententries">
<span class="toptitle"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icon-comments.gif" alt="icon comments" class="icons" />Recent Posts</span>
<ul class="list2">
<?php $my_query = new WP_Query("showposts=4");
while ($my_query->have_posts()) : $my_query->the_post(); ?>
<li><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '50') ?></a></li>
<?php endwhile; ?>
</ul>
</div>

<div id="recentcomments2">
<span class="toptitle"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icon-comments2.gif" alt="icon comments" class="icons" />Recent Comments</span>
<?php include (TEMPLATEPATH . '/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */?>
<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(4, 35, '', ''); } ?>
</div>


<div id="mostcomments">
<span class="toptitle"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icon-popular.gif" alt="icon comments" class="icons" />Popular Articles</span>
<ul>
<?php
	$sql='SELECT post_title, comment_count, guid
		FROM wp_posts
		ORDER BY comment_count DESC
		LIMIT 4;';
	$results = $wpdb->get_results($sql);

	foreach ($results as $r) {
		echo '<li><a href="' . $r->guid . '" title="' . $r->post_title . '"> ' . $r->post_title .
			' (' . $r->comment_count . ')</a></li>';
	}
?>
</ul>
</div>
</div>
<div id="recent-right">

		<div id="aboutus">
		<span class="toptitle2"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/icon-about.gif" alt="icon comments" class="icons" />About Us</span>
		<?php include 'about.php';?>
		</div>
</div>
</div>
</div>
