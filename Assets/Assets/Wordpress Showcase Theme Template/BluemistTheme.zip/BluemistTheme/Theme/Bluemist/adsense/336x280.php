<script type="text/javascript"><!--
google_ad_client = "pub-6734752749309808";
/* 336x280, created 7/4/08 */
google_ad_slot = "0897019234";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>