﻿
<?php get_header(); ?>	

<div id="featured">
<div id="featured-bg">
 <?php $my_query = new WP_Query('category_name=Featured Articles&showposts=1');
  while ($my_query->have_posts()) : $my_query->the_post();
  $do_not_duplicate = $post->ID; ?>

<span class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></span>
			<div id="featured-left">
			<a href="<?php the_permalink() ?>"><img style="padding:1px; margin:0px; border:0px; border: 5px solid #F7F7F7;" height="122" width="384" alt="featured article" src="<?php echo get_post_meta($post->ID, "Featured", true); ?>" /></a>
			</div>
			<div id="featured-right">
			<?php the_content_limit(500, ""); ?>
			</div>
			<div style="clear: both;"></div>
  <?php endwhile; ?>
</div>
</div>

	<div id="wrapper">
	
		<div id="content-wrapper">
		
			<div id="content">
			
			
			
 <?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

			


		<?php 
		// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
				 ?>
				<div class="post-wrapper">
				
			<div class="post">

<div class="homepost-left">
<div class="thumbnailwrap">
<?php // if there's a thumbnail
if($thumb !== '') { ?>

	<img src="<?php echo $thumb; ?>"
	class="thumbnail-home" width="94px" height="94px"
	alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"
	/>

<?php } // end if statement

// if there's not a thumbnail

else { echo ''; } ?>

</div>
<?php Show_Dropdown(); ?>
</div>
			
			<div class="homepost-right">
			<h2 class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
			<?php the_content_limit(300, ""); ?>
			</div>

			</div>
			
			</div>

			<?php comments_template(); ?>

			<?php endwhile; ?>

			   <p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>

			<?php else : ?>

			<h2 >No Results Found</h2>

			<p>Sorry, your search returned zero results. </p>

			<?php endif; ?>
			
			
	
			</div>
		
		</div>
		<?php get_sidebar(); ?>    
		<?php get_footer(); ?>   
	
</body>
</html>