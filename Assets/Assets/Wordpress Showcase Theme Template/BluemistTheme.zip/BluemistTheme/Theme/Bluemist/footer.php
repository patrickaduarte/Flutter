								 <div id="footer">
 
&copy; Copyright <?php bloginfo('name'); ?> 2008. All rights reserved. | Powered by <a href="http://www.wordpress.org">Wordpress</a> | Designed by <a href="http://www.elegantthemes.com">Elegant Themes</a>
 </div>
</div>

<?php wp_footer(); ?>