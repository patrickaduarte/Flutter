<?php
require_once( dirname(__FILE__) . '../../../../wp-config.php');
require_once( dirname(__FILE__) . '/functions.php');
header("Content-type: text/css");

global $options;

foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>

body {
margin-top: 0px;
padding: 0;
color: #84878E;
background-color:#EAEAE1;
background-image: url(images/bg.gif);
background-repeat: repeat-x;
font-family: <?php echo $artsee_body_font; ?>;
font-size: 11px;
line-height: 18px;
}

#wrapper2 {
width: 950px;
margin-left: auto;
margin-right: auto;
padding: 0px 0px 0px 0px;
background-color: #FFF;
margin-top: 33px;
background-image: url(images/top-left.gif);
background-position: top left;
background-repeat: no-repeat;
}

.single-entry {
float: left;
width: 100%;
margin-bottom: 10px;
padding: 0px;
}
.post-wrapper {
background-color: #FFF;
padding: 15px;
width: 583px;
border: 1px solid <?php echo $artsee_content_border; ?>;
}

a:link { 
text-decoration: none; 
color: <?php echo $artsee_link_color; ?>; 
}

a:visited { 
text-decoration: none; 
color: <?php echo $artsee_link_color; ?>; 
}

a:hover, a:active { 
color: #3B3B3B; 
}

h1, h2, h3, h4, h5, h6 { 
font-weight: normal; 
margin: 0px 0 10px; 
}

h1 { 
font-size: 32px; 
margin-bottom: 0px; 
margin-top: 10px;
}

h2 { 
font-size: 28px; 
}

h3 { 
font-size: 24px;
}

.post-title {
line-height: 30px;
font-size: 24px;
margin-top: 0px;
}

.home-post-wrap {
width: 613px;
margin-right: 13px;
float: left;
background-color: #FFF;
border: 1px solid <?php echo $artsee_content_border; ?>;
}

.home-post-wrap2 {
width: 593px;
padding: 10px;
margin-right: 13px;
float: left;
background-color: #FFF;
border: 1px solid <?php echo $artsee_content_border; ?>;
margin-bottom: 10px;
}

.home-categories img{
border: 4px solid #EEEEEE;
float: left;
margin-right: 10px;
}

.index-post-wrap {
width: 593px;
margin-right: 13px;
margin-bottom: 10px;
float: left;
background-color: #FFF;
border: 1px solid <?php echo $artsee_content_border; ?>;
padding: 10px;
}

.readmore {
background-image: url(images/bullet.gif);
background-repeat: no-repeat;
background-position: left;
float: right;
padding-left: 20px;
margin-top: 10px;
}

.readmore a:link, .readmore a:hover {
color: #393939;
}
.thumbnail-home {
border: 0px;
margin: 0px 0px 0px 0px;
}

h4, h5, h6 { 
font-size: 20px; 
}

.titles { 
font-weight: normal; 
font-size: 24px; 
text-decoration: none;
}

.titles a:link, .titles a:visited, .titles a:active {
text-decoration: none;
font-size: 20px;
font-weight: bold;
font-family: Trebuchet MS;
text-transform: uppercase;
margin-bottom: 10px;
margin-top: 10px;
display: block;
}

.titles-featured a, .titles-featured a:hover, .titles-featured {
font-size: 30px;
line-height: 30px;
}

pre, blockquote {
overflow: auto;
padding: 0 10px;
margin: 20px 30px;
line-height: 1.8em;
background-color: #f5f5f5;
border: 1px solid #e0e0e0;
}

pre:hover, blockquote:hover {
background-color: #f0f0f0;
border: 1px solid #d0d0d0;
}


ul { 
list-style-image: url(images/bullet.gif); 
}

#pages {
width: 950px;
float: left;
background-image: url(images/top-right.gif);
background-position: top right;
background-repeat: no-repeat;
min-height: 68px;
}

#categories {
width: 950px;
min-height: 48px;
background-image: url(images/categories-bg.gif);
background-repeat: repeat-x;
float: left;
background-color: #433D3D;
}

#categories ul {
margin: 0px 0px 0px 10px;
padding-left: 0px;
list-style-type: none; 
list-style-image: none; 
float: left;
}

#categories ul li {
float: left; 
display: block; 
padding-left: 0px; 
height: 48px;
}

#categories ul li a:link,#categories ul li a:visited, #categories ul li a:active, #categories ul li a:hover   {
height: 36px;
display: block;
color: <?php echo $artsee_cat_color; ?>;
font-size: 11px;
font-weight: bold;
padding: 12px 10px 0px 10px;
background-image: url(images/categories-line.gif);
background-repeat: no-repeat;
background-position: right;
float: left;
}

#categories ul li a:hover {
background-image: url(images/categories-hover.gif);
background-repeat: repeat-x !important;
}

#header {
width: 950px;
margin-top: 0px;
height: 219px;
background-color: #373434;
background-image: url(images/header-bg.gif);
background-repeat: repeat-x;
float: left;
}

#container {
float: right;
width: 950px;
color: <?php echo $artsee_font_color; ?>;
background-image: url(images/content-bg.gif);
}

#left-div {
width: 646px;
float: left;
}

#left-inside {
float: left;
padding: 0px 0px 0px 19px;
}

.adwrap {
margin-left: 26px;
}

#sidebar-wrapper {
width: 300px;
float: left;
margin-bottom: 20px;
}

#sidebar {
float: left;
padding-left: 0px;
padding-right: 13px;
width: 287px;
}

#footer {
clear: both;
width: 930px;
height: 31px;
padding-left: 20px;
text-align: left;
color: #C3B8B6;
padding-top: 14px;
background-image: url(images/footer.gif);
background-repeat: no-repeat;
margin-left: auto;
margin-right: auto;
font-size: 11px;
}

#footer a {
color: #C3B8B6;
font-size: 11px;
}

#footer a:visited {
color: #C3B8B6;
}

#footer a:hover {
color: #C3B8B6;
text-decoration: underline;
}

#extras {
float: left;
width: 780px;
color: #C7AA92;
text-align: left;
padding: 0 10px 10px;
margin: 10px 12px 20px;
background-color: #f5f5f5;
border-top: 1px solid #e0e0e0;
border-bottom: 1px solid #e0e0e0;
}

#pages ul { 
list-style-type: none; 
list-style-image: none; 
float: left; 
padding: 0px 0px 0px 0px; 
margin-left: 10px; 
margin-top: 0px; 
margin-bottom: 0px;
}
#pages li { 
float: left; 
display: block; 
margin-top: 0px; 
margin-bottom: 0px;
}

#pages li:hover {
background-image: url(images/pages-hover.gif);
}

#pages li a:link, #pages li a:visited {
float: left;
color: <?php echo $artsee_nav_color; ?>;
display: block;
height: 45px;
padding-top: 23px;
font-size: 14px;
padding-left: 20px;
padding-right: 20px;
margin-bottom: 0px;
}

#pages li a:hover, #pages li a:active {
color: <?php echo $artsee_nav_color; ?>;
font-size: 14px;
margin-bottom: 0px;
background-image: url(images/pages-arrow.gif);
background-position: top;
background-repeat: no-repeat;
}

.sidebar-box {
padding-top: 5px;
margin-bottom: 0px;
}

.sidebar-box2 {
padding-left: 15px;
}

.articleinfo {
border-bottom: 1px solid #EEEEEE; padding-bottom: 7px; color: #545454;
}

.sidebar-box ul li a:link, .sidebar-box ul li a:visited, .sidebar-box ul li a:active {
display: block; 
color: #373434; 
width: 100%; 
padding: 3px 3px 3px 3px; 
background-image: none !important;
} 

.sidebar-box ul li {
color: #373434 !important;
}

.sidebar-box ul li a:hover {
width: 100%;
display: block; 
color: #393939; 
padding: 3px 3px 3px 3px;
} 

.sidebar-box h2 { 
margin-top: 5px; 
font-size: 11px; 
color: #FF8400; 
padding-top: 9px; 
font-weight: normal; 
text-transform: lowercase; 
font-weight: bold; 
margin-left: 0px; 
font-family: Trebuchet MS; 
background-image: url(images/h3-bg.gif); 
background-repeat: no-repeat; 
background-position: left; 
width: 263px; 
height: 30px; 
padding-left: 10px;
}

#commentform {
margin: 1em 0;
background: #FFFFFF;
margin-left: 20px;
}

#commentform textarea {
background: #f8f7f6;
border: 1px solid #d6d3d3;
width: 370px;
}

#commentform #email {
font-size: 1.1em;
background: #f8f7f6;
border: 1px solid #d6d3d3;
width: 280px;
background-image: url(images/comment-email.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}

#commentform #author {
font-size: 1.1em;
background: #f8f7f6;
border: 1px solid #d6d3d3;
width: 280px;
background-image: url(images/comment-author.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}

#commentform #url {
font-size: 1.1em;
background: #f8f7f6;
border: 1px solid #d6d3d3;
width: 280px;
background-image: url(images/comment-website.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}

#commentform #email:focus {
font-size: 1.1em;
background: #ffffff;
border: 1px solid #939793;
width: 280px;
background-image: url(images/comment-email.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}

#commentform #author:focus {
font-size: 1.1em;
background: #ffffff;
border: 1px solid #939793;
width: 280px;
background-image: url(images/comment-author.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}

#commentform #url:focus {
font-size: 1.1em;
background: #ffffff;
border: 1px solid #939793;
width: 280px;
background-image: url(images/comment-website.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}

#commentform input {
margin-bottom: 3px;
}

.search_bg {
height:35px;
width:260px;
float: left;
margin-top: 10px;
margin-left: 10px;
}

#search {
color:#FFFFFF;
padding:0;
}

#search input {
background: #FFF;
font-size:11px;
color:#B8B8B8;
font-family:Tahoma, arial, verdana, courier;
width:150px;
height:11px;
vertical-align:middle;
padding:10px;
border: 1px solid #E7E7DC;
}

.icons {
margin-top: 0px; 
margin-bottom: -5px;
margin-right: 10px;
}

#search .input {
width:66px;
height:31px;
background:none;
border:none;
vertical-align:middle;
margin:0;
padding:0;
margin-left: 10px;
}

.thumbnail-div {
border: 1px solid #DFDFDF;
width: 120px;
height: 120px;
padding: 4px;
margin-bottom: 10px;
float: left;
margin-right: 10px;
display: inline;
}

.post-info {
margin-bottom: 10px;
color: #000;
font-size: 10px;
}

.post-inside {
float: left;
width: 245px;
}

.post-inside-2 {
float: left;
width: 450px;
}

#home-right {
width: 187px;
float: right;
padding: 10px;
border-left: 1px solid <?php echo $artsee_content_border; ?>;
border-bottom: 1px solid <?php echo $artsee_content_border; ?>;
}

#home-right ul {
list-style-image: url(images/bullet-home.gif);
float: left;
}

#home-left {
float: left;
width: 385px;
padding: 10px;
}

.home-categories, .home-categories-comments {
width: 280px;
min-height: 180px;
border: 1px solid <?php echo $artsee_content_border; ?>;
padding: 10px;
margin-top: 10px;
margin-right: 10px;
float: left;
}

.home-categories-comments ul {
list-style-image: url(images/comment-icon.gif);
}

.home-categories a:link, .home-categories a:hover, .home-categories a:visited {
color: #5F666F;
text-transform: uppercase;
font-size: 15px;
font-weight: bold;
}

.logo {
float: left; 
margin-bottom: 15px;
border: 0px;
margin-left: 40px;
margin-top: 68px;
}

a:focus {
outline: none;
}

.share-div {
width: 590px;
height: 30px;
background-color: #FFF;
display: none;
}

.share {
visibility: <?php echo $artsee_share; ?>;
}

.random-image {
width: 44px;
height: 44px;
border: 4px solid #F2F2E4;
float: left;
margin-left: 10px;
}

.random-content {
float: right;
width: 210px;
}

.random-content a:link {
font-size: 13px;
}
.random {
width: 280px;
float: left;
margin-top: 10px;
}

.orange-titles {
color: #FF8400;
font-size: 10px;
font-weight: bold;
text-transform: lowercase;
display: block;
margin-bottom: 5px;
width: 100%;
}

ul, ol { line-height: 2.0em; }

/* Captions */
.aligncenter,
div.aligncenter {
	display: block;
	margin-left: auto;
	margin-right: auto;
}

.wp-caption {
	border: 1px solid #ddd;
	text-align: center;
	background-color: #f3f3f3;
	padding-top: 4px;
	margin: 10px;
	-moz-border-radius: 3px;
	-khtml-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
}

.wp-caption img {
	margin: 0;
	padding: 0;
	border: 0 none;
}

.wp-caption p.wp-caption-text {
	font-size: 11px;
	line-height: 17px;
	padding: 0 4px 5px;
	margin: 0;
}
/* End captions */

/* Begin Images */
p img {
	padding: 0;
	max-width: 100%;
	}

/*	Using 'class="alignright"' on an image will (who would've
	thought?!) align the image to the right. And using 'class="centered',
	will of course center the image. This is much better than using
	align="center", being much more futureproof (and valid) */

img.centered {
	display: block;
	margin-left: auto;
	margin-right: auto;
	}

img.alignright {
	padding: 4px;
	margin: 0 0 2px 7px;
	display: inline;
	}

img.alignleft {
	padding: 4px;
	margin: 0 7px 2px 0;
	display: inline;
	}

.alignright {
	float: right;
	}

.alignleft {
	float: left
	}
/* End Images */

/* Begin Comments*/

.commentlist {
padding: 0px;
margin: 0px 0px 0px 17px;
width: 560px;
background-image: url(images/comment-bg.gif);
list-style-image: none;
list-style-type: none;
float: left;
}

.commentlist li {
	font-weight: bold;
	width: 560px;
	display: block;
	background-image: url(images/comment-bottom.gif);
	background-repeat: no-repeat;
	background-position: bottom left;
	padding: 0px 0px 45px 0px;
	margin: 0px;
	list-style-image: none;
	list-style-type: none;
	float: left;
	}

.commentlist li div {
	width: 540px;
	display: block;
	background-image: url(images/comment-top.gif);
	background-repeat: no-repeat;
	margin: 0px;
	padding: 10px;
	float: left;
}

.commentlist li .avatar { 
	float: left;
	border: 1px solid #eee;
	padding: 2px;
	background: #fff;
	}

.commentlist cite {
	font-size: 18px;
	float: left;
	font-style: normal;
	margin-left: 10px;
	margin-right: 6px;
	margin-top: 5px;
	font-weight: normal;
	}
	
.says {
display: none;
}

.commentlist p {
	font-weight: normal;
	line-height: 1.5em;
	text-transform: none;
	display: block;
	float: left;
	width: 90%;
	margin-left: 3%;
	}
	

#commentform p {
clear: both;
	}

.alt {
	margin: 0;
	padding: 10px;
	}

.nocomments {
	text-align: center;
	margin: 0;
	padding: 0;
	}

.commentlist .children li {
	width: 90%;
	display: block;
	margin: 0px;
	background-color: #FDFDFD;
	background-image: url(images/comment-children-bg.gif);
	background-position: left;
	background-repeat: repeat-y;
	border: 1px solid #E2E2E4;
	overflow: hidden;
}

.commentlist .children li div {
width: 97%;
padding: 3%;
background-image: url(images/comment-children-top.gif);
background-repeat: no-repeat;
background-position: top left;
}

.commentlist .commentmetadata {
	font-weight: normal;
	float: left;
	margin: 5px 0px 0px 0px;
	display: block;
	clear: both;
	background-image: none;
	width: 90%;
	margin-left: 3%;
	}
	
.commentlist .vcard, .commentlist .children .comment-author, .commentlist .children .vcard, .commentlist .commentmetadata, .commentlist .children .comment-author, .commentlist .children .comment-meta   {
	background-image: none;
	width: 100%;
	padding: 0px !important;
}

.commentlist .reply, .commentlist .children .reply {
	float: right;
	background-image: none;
	width: 54px;
	height: 22px;
	margin-bottom: 0px;
	padding: 0px;
	margin-right: 10px;
	font: 0.9em 'Lucida Grande', Verdana, Arial, Sans-Serif;
}

.commentlist .reply a:link, .commentlist .reply a:hover, .commentlist .children .reply a:link, .commentlist .children .reply a:hover {
	background-image: url(images/reply.gif);
	width: 39px;
	height: 17px;
	display: block;
	color: #FFF;
	font-size: 8px;
	text-transform: lowercase;
	font-weight: normal;
	padding: 5px 0px 0px 15px;
	letter-spacing: 1px;
}

.commentlist .children li {
padding-bottom: 10px;
}

.commentlist .children li ul li {
padding-bottom: 10px;
background-color: #FFF;
}

#respond {
margin-top: 20px;
float: left;
background-image: none;
}

.commentlist #respond h3, .commentlist #respond a {
margin-left: 28px;
}

#comments {
line-height: 30px;
}

.children {
clear: both;
}

.children .commentmetadata, .children .vcard  {
	background-image: none;
}

.children textarea {
width: 90% !important;
}

.children input {
width: 80% !important;
}

#cancel-comment-reply-link {
display: block;
background-image: url(images/comment-close.gif);
width: 144px;
height: 21px;
padding: 5px 0px 0px 23px;
font-weight: normal;
color: #84878E;
font: 1em 'Lucida Grande', Verdana, Arial, Sans-Serif;
}

#respond div {
background-image: none;
}

#submit {
width: 120px !important;
}

/* End Comments */