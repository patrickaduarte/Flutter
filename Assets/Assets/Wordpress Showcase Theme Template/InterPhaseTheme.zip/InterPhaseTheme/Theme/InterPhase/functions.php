<?php 

function the_title2($before = '', $after = '', $echo = true, $length = false) {
         $title = get_the_title();

      if ( $length && is_numeric($length) ) {

             $title = substr( $title, 0, $length );

          }

        if ( strlen($title)> 0 ) {

             $title = apply_filters('the_title2', $before . $title . $after, $before, $after);

             if ( $echo )

                echo $title;

             else

                return $title;

          }

      }

?>
<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '<div class="sidebar-box">',
    'after_widget' => '</div></div>',
 'before_title' => '<h2>',
        'after_title' => '</h2><div class="sidebar-box2">',
    ));
?>
<?php
$themename = "InterPhase Theme";
$shortname = "artsee";
$options = array (
      
    array(    "name" => "Content Border Color",
            "id" => $shortname."_content_border",
            "std" => "#EBEBEB",
            "type" => "text"),
			
	array(    "name" => "Link Color",
            "id" => $shortname."_link_color",
            "std" => "#5F666F",
            "type" => "text"),
			
	array(    "name" => "Navigation Link Color <br><span style='font-size: 10px; color: #FF8A00;'>(controls the color of the Pages links)</span>",
            "id" => $shortname."_nav_color",
            "std" => "#8D8D8D",
            "type" => "text"),
			
	array(    "name" => "Categories Link Color <br><span style='font-size: 10px; color: #FF8A00;'>(controls the color of category links)</span>",
            "id" => $shortname."_cat_color",
            "std" => "#FFFFFF",
            "type" => "text"),
				
	array(    "name" => "Font Color",
            "id" => $shortname."_font_color",
            "std" => "#84878E",
            "type" => "text"),
    
    array(    "name" => "Font Family",
            "id" => $shortname."_body_font",
            "type" => "select",
            "std" => "Trebuchet MS",
            "options" => array("Trebuchet MS", "Verdana", "Arial", "Georgia")),
			
    array(    "name" => "Hide/Display Share Button <br><span style='font-size: 10px; color: #FF8A00;'>(choosing hidden will remove the <br>share button one post pages)</span>",
            "id" => $shortname."_share",
            "type" => "select",
            "std" => "visible",
            "options" => array("visible", "hidden")),
				
	array(    "name" => "Homepage Category 1 Name",
            "id" => $shortname."_cat_one_name",
            "std" => "category one",
            "type" => "text"),

	array(    "name" => "Home Category 1 ID",
            "id" => $shortname."_home_cat_one",
            "std" => "6",
            "type" => "text"),
			
	
	array(    "name" => "Homepage Category 2 Name",
            "id" => $shortname."_cat_two_name",
            "std" => "category two",
            "type" => "text"),
			
	array(    "name" => "Home Category 2 ID",
            "id" => $shortname."_home_cat_two",
            "std" => "3",
            "type" => "text"),
			
	array(    "name" => "Homepage Category 3 Name",
            "id" => $shortname."_cat_three_name",
            "std" => "category three",
            "type" => "text"),
			
	array(    "name" => "Home Category 3 ID",
            "id" => $shortname."_home_cat_three",
            "std" => "4",
            "type" => "text"),
			
	array(    "name" => "Homepage Category 4 Name",
            "id" => $shortname."_cat_four_name",
            "std" => "category four",
            "type" => "text"),
			
	array(    "name" => "Home Category 4 ID",
            "id" => $shortname."_home_cat_four",
            "std" => "5",
            "type" => "text"),
			
    array(    "name" => "Number of Posts Displayed on Homepage<br><span style='font-size: 10px; color: #FF8A00;'>(this controls how many recent posts <br> to display on the homepage)</span>",
            "id" => $shortname."_homepage_posts",
            "std" => "4",
            "type" => "text"),
			
	array(    "name" => "125x125 Banner #1 Image",
            "id" => $shortname."_banner_image_one",
            "std" => "http://www.elegantwordpressthemes.com/preview/InterPhase/wp-content/themes/InterPhase/images/125x125.gif",
            "type" => "text"),
			
	array(    "name" => "125x125 Banner #1 URL",
            "id" => $shortname."_banner_url_one",
            "std" => "#",
            "type" => "text"),
			
	array(    "name" => "125x125 Banner #2 Image",
            "id" => $shortname."_banner_image_two",
            "std" => "http://www.elegantwordpressthemes.com/preview/InterPhase/wp-content/themes/InterPhase/images/125x125.gif",
            "type" => "text"),
			
	array(    "name" => "125x125 Banner #2 URL",
            "id" => $shortname."_banner_url_two",
            "std" => "#",
            "type" => "text"),
			
	array(    "name" => "125x125 Banner #3 Image",
            "id" => $shortname."_banner_image_three",
            "std" => "http://www.elegantwordpressthemes.com/preview/InterPhase/wp-content/themes/InterPhase/images/125x125.gif",
            "type" => "text"),
			
	array(    "name" => "125x125 Banner #3 URL",
            "id" => $shortname."_banner_url_three",
            "std" => "#",
            "type" => "text"),
		
	array(    "name" => "125x125 Banner #4 Image",
            "id" => $shortname."_banner_image_four",
            "std" => "http://www.elegantwordpressthemes.com/preview/InterPhase/wp-content/themes/InterPhase/images/125x125.gif",
            "type" => "text"),
			
	array(    "name" => "125x125 Banner #4 URL",
            "id" => $shortname."_banner_url_four",
            "std" => "#",
            "type" => "text"),
			
	array(    "name" => "Flickr User ID Number<br><span style='font-size: 10px; color: #FF8A00;'>(enter your fickr ID here. <br> Don't know your ID#? Go here: <br> <a href='http://idgettr.com/'>ID Finder</a>)</span>",
            "id" => $shortname."_flickr",
            "std" => "29622357%40N07",
            "type" => "text"),
			
			
);

function mytheme_add_admin() {

    global $themename, $shortname, $options;

    if ( $_GET['page'] == basename(__FILE__) ) {
    
        if ( 'save' == $_REQUEST['action'] ) {

                foreach ($options as $value) {
                    update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }

                foreach ($options as $value) {
                    if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }

                header("Location: themes.php?page=functions.php&saved=true");
                die;

        } else if( 'reset' == $_REQUEST['action'] ) {

            foreach ($options as $value) {
                delete_option( $value['id'] ); }

            header("Location: themes.php?page=functions.php&reset=true");
            die;

        }
    }

    add_theme_page($themename." Options", "Current Theme Options", 'edit_themes', basename(__FILE__), 'mytheme_admin');

}

function mytheme_admin() {

    global $themename, $shortname, $options;

    if ( $_REQUEST['saved'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings saved.</strong></p></div>';
    if ( $_REQUEST['reset'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings reset.</strong></p></div>';
    
?>
<div class="wrap">
<h2><?php echo $themename; ?> settings</h2>

<form method="post">

<table class="optiontable">

<?php foreach ($options as $value) { 
    
if ($value['type'] == "text") { ?>
        
<tr valign="top"> 
    <th scope="row"><?php echo $value['name']; ?>:</th>
    <td>
        <input name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo get_settings( $value['id'] ); } else { echo $value['std']; } ?>" />
    </td>
</tr>
  
<?php } elseif ($value['type'] == "text2") { ?>
        
<tr valign="top"> 
    <th scope="row"><?php echo $value['name']; ?>:</th>
    <td>
        <textarea name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" style="width: 400px; height: 200px;" type="<?php echo $value['type']; ?>"><?php if ( get_settings( $value['id'] ) != "") { echo get_settings( $value['id'] ); } else { echo $value['std']; } ?></textarea>
   <div style="float: left;"><span style='font-size: 10px; color: #4A7CB5;'>(the following control what posts are displayed in the 4 boxes in the middle of the homepage)</span></div>
    </td>
</tr>

<?php } elseif ($value['type'] == "select") { ?>

    <tr valign="top"> 
        <th scope="row"><?php echo $value['name']; ?>:</th>
        <td>
            <select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
                <?php foreach ($value['options'] as $option) { ?>
                <option<?php if ( get_settings( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>><?php echo $option; ?></option>
                <?php } ?>
            </select>
        </td>
    </tr>

<?php 
} 
}
?>

</table>

<p class="submit">
<input name="save" type="submit" value="Save changes" />    
<input type="hidden" name="action" value="save" />
</p>
</form>
<form method="post">
<p class="submit">
<input name="reset" type="submit" value="Reset" />
<input type="hidden" name="action" value="reset" />
</p>
</form>

<?php
}

function mytheme_wp_head() { ?>
<link href="<?php bloginfo('template_directory'); ?>/style.php" rel="stylesheet" type="text/css" />
<?php }

add_action('wp_head', 'mytheme_wp_head');
add_action('admin_menu', 'mytheme_add_admin'); ?>