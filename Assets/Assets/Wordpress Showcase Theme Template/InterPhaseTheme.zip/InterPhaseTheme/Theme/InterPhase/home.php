﻿<?php get_header(); ?>	
<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
<div id="container">
	
<div id="left-div">
		
<div id="left-inside">

<div class="home-post-wrap">	

<!--Begins recent posts section of the homepage-->
<div id="home-left">		
<span class="orange-titles">recent posts</span>

<!--Begind recent post (single)-->
<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<?php static $ctr = 0; 
if ($ctr == "$artsee_homepage_posts;") { break; } 
else { ?>

<!--The Following code checks for yout thumbnail image-->
		<?php 
		// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
				 ?>
<h2 class="titles"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '30') ?></a></h2>

<!--Display thumbnail if found-->
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<div class="thumbnail-div">
<img src="<?php echo $thumb; ?>" width="120px" height="120px" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" />
</div>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>

<div class="post-inside">
<span class="post-info">Posted by <?php the_author() ?> on  <?php the_time('F j, Y') ?></span>
<?php the_content_limit(245, ""); ?>
</div>	
			
<div style="clear:both;"></div>	

<?php $ctr++; } ?>

<?php endwhile; ?>
<!--end recent post (single)-->

</div>

<!--The folloing displayes the popular/random posts on homepage-->
<div id="home-right">
<span class="orange-titles">popular posts</span>
<div style="clear: both;"></div>
<ul>
<?php
	$sql='SELECT post_title, comment_count, guid
		FROM wp_posts
		ORDER BY comment_count DESC
		LIMIT 6;';
	$results = $wpdb->get_results($sql);

	foreach ($results as $r) {
		echo '<li><a href="' . $r->guid . '" title="' . $r->post_title . '"> ' . $r->post_title .
			' (' . $r->comment_count . ')</a></li>';
	}
?>
</ul>
<div style="clear: both;"></div>
<span class="orange-titles">random posts</span>
<div style="clear: both;"></div>
<ul>
<?php $my_query = new WP_Query('orderby=rand&showposts=6');
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '50') ?></a></li>
 <?php endwhile; ?>
</ul>
</div>
</div>
<!--end random/popular posts-->

<?php else : ?>

<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>

<?php endif; ?>

<!--The following code controls the category boxes-->

<!--Category Box 1-->
<?php query_posts("cat=$artsee_home_cat_one;&showposts=1"); ?>
<?php while (have_posts()) : the_post(); ?>
<div class="home-categories">
<span class="orange-titles">recent from <?php echo $artsee_cat_one_name; ?></span>
<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
<?php the_content_limit(300, ""); ?>
</div>
<?php endwhile; ?>
<!--End Category Box 1-->	
		
<!--Category Box 2-->
<?php query_posts("cat=$artsee_home_cat_two;&showposts=1"); ?>
<?php while (have_posts()) : the_post(); ?>
<div class="home-categories">
<span class="orange-titles">recent from <?php echo $artsee_cat_two_name; ?></span>
<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
<?php the_content_limit(300, ""); ?>
</div>
<?php endwhile; ?>
<!--End Category Box 2-->

<div style="clear: both;"></div>

<!--Category Box 3-->
<?php query_posts("cat=$artsee_home_cat_three;&showposts=1"); ?>
<?php while (have_posts()) : the_post(); ?>
<div class="home-categories">
<span class="orange-titles">recent from <?php echo $artsee_cat_three_name; ?></span>
<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
<?php the_content_limit(300, ""); ?>
</div>
<?php endwhile; ?>
<!--Category Box 3-->

<!--Category Box 4-->
<?php query_posts("cat=$artsee_home_cat_four;&showposts=1"); ?>
<?php while (have_posts()) : the_post(); ?>
<div class="home-categories">
<span class="orange-titles">recent from <?php echo $artsee_cat_four_name; ?></span>
<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
<?php the_content_limit(300, ""); ?>
</div>
<?php endwhile; ?>	
<!--Category Box 4-->

<div style="clear: both;"></div>

<!--Recent Comments-->
<div class="home-categories-comments">
<span class="orange-titles">recent comments</span>
<?php include (TEMPLATEPATH . '/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */?>
<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(5, 60, '', ''); } ?>
</div>
<!--End Recent Comments-->

<!--Flickr Photos-->
<div class="home-categories">
<span class="orange-titles">recent flickr photos</span>
<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=9&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user=<?php echo $artsee_flickr; ?>"></script>
</div>	
<!--End Flickr Photos-->

</div>
		
</div>

<?php get_sidebar(); ?>    
<?php get_footer(); ?>   
	
</body>
</html>