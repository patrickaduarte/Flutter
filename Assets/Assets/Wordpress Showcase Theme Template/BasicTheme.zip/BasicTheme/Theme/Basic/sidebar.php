<div id="sidebar">
<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>

<div id="header">
<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/logo-<?php echo $artsee_color; ?>.gif" alt="<?php bloginfo('name'); ?> Logo" class="logo" /></a>
</div>

<div id="about">
<h2>About Me</h2>
<div id="about-content">
<div id="about-image-border">
<img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $artsee_about_image; ?>&amp;h=68&amp;w=68&amp;zc=1" alt="about me" id="about-image" />
</div>

<?php echo stripslashes("$artsee_about;"); ?>

<a href="<?php echo $artsee_about_link; ?>" rel="bookmark" class="readmore" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/readmore-about.gif" alt="read more" style="border: none;" /></a>
</div>
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/about-bottom-<?php echo $artsee_color; ?>.gif" alt="about bottom" style="float: left;" />
</div>

<div style="margin-top: 18px;">
<!--Begin 125x125 Ad Block-->
<?php if (get_option('artsee_ads') == 'Enable') { ?>
<?php include(TEMPLATEPATH . '/includes/ads.php'); ?>
<?php } else { echo ''; } ?>
<!--End 125x125 Ad Block-->

</div>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>     
		       
<div class="sidebar-box">
<h2>Archives</h2>
<ul>
<?php wp_get_archives('type=monthly'); ?>
</ul>
</div>

<div class="sidebar-box">
<h2>Categories</h2>
<ul>
<?php wp_list_categories('show_count=0&title_li='); ?>
</ul>
</div>

<div class="sidebar-box">           
<h2>Blogroll</h2>
<ul>
<?php get_links(-1, '<li>', '</li>', ''); ?>
</ul> 
</div>

<div class="sidebar-box">
<h2>Search</h2>
<div style="margin-left: 20px;">
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</div>
</div>

<div class="sidebar-box">   
<h2>Meta</h2>
<ul>
<?php wp_register(); ?>
<li><?php wp_loginout(); ?></li>
<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
<?php wp_meta(); ?>
</ul>
</div>

<?php endif; ?>
                
</div>      
</div>
