﻿<div class="home-post-wrap2">
<div style="float: left; width: 50%;">
<span class="headings">Popular Articles</span>
<ul class="list2">
<?php
	$sql='SELECT post_title, comment_count, guid
		FROM wp_posts
		ORDER BY comment_count DESC
		LIMIT 6;';
	$results = $wpdb->get_results($sql);

	foreach ($results as $r) {
		echo '<li><a href="' . $r->guid . '" title="' . $r->post_title . '"> ' . $r->post_title .
			' (' . $r->comment_count . ')</a></li>';
	}
?>
</ul>
</div>
<div style="float: left; width: 50%;">
<span class="headings">Random Articles</span>
<ul>
 <?php $my_query = new WP_Query('orderby=rand&showposts=6');
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '', true, '400') ?></a></li>
<?php endwhile; ?>
</ul>
</div>
</div>