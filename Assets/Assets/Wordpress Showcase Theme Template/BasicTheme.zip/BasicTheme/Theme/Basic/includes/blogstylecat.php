<span class="current-category">
<?php single_cat_title('Currently Browsing: ', 'display'); ?>
</span>

<!--Begind recent post-->
<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>


<div class="home-post-wrap">	

<h1 class="titles"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title() ?></a></h1>
<span class="post-info">Posted by <?php the_author() ?> in  <?php the_category(', ') ?></span><span class="post-info2"><?php the_time('M jS, Y') ?> | <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></span>
<div style="clear: both;"></div>

<?php $thumb = get_post_meta($post->ID, 'Thumbnail', $single = true); ?>
<?php 
if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=190&amp;w=190&amp;q=100&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  class="thumbnail" /></a>
<?php }
else { echo ''; } ?>

<?php the_content(); ?>
</div>


<?php endwhile; ?>

<div style="clear: both;"></div>
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
else { ?>
<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>
<?php } ?>

<!--end recent post-->

<?php else : ?>

<!--If no results are found-->
<div class="home-post-wrap2">
<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
</div>
<!--End if no results are found-->

<?php endif; ?>