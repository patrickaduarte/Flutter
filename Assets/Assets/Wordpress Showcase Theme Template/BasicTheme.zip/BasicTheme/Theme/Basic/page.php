﻿<?php get_header(); ?>	
<div id="container">
<div id="left-div">
<div id="left-inside">

<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

<!--Start Post-->
<div class="home-post-wrap">	

<h1 class="titles"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title() ?></a></h1>
<div style="clear: both;"></div>
<?php the_content(''); ?>
</div>

<?php endwhile; ?>

<!--End Post-->

<?php else : ?>

<h2 align="center">Not Found</h2>
<p align="center">Sorry, but the page you requested could not be found.</p>

<?php endif; ?>

</div>
	
</div>

<!--Begin Sidebar-->
<?php get_sidebar(); ?>
<!--End Sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>
<!--End Footer-->
	
</body>
</html>