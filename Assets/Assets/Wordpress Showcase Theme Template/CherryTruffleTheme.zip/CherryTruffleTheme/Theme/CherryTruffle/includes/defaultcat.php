<div id="container">
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/content-top-home.gif" alt="logo" style="float: left;" />
<div id="left-div">

<!--Begind recent post-->
<span class="current-category">
<?php single_cat_title('Currently Browsing: ', 'display'); ?>
</span>
<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<div class="home-post-wrap">	

<div class="date">
<div class="month"><?php the_time('M') ?></div>
<div style="clear: both;"></div>
<div class="day"><?php the_time('j') ?></div>
</div>

<div class="post-right">
<div class="featured-categories"><?php the_category('') ?></div><span class="author-link"><?php the_author_posts_link(); ?> </span>
<div style="clear: both;"></div>
<h2 class="titles"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title() ?></a></h2>
<div style="clear: both;"></div>
<?php $thumb = get_post_meta($post->ID, 'Thumbnail', $single = true); ?>
<?php if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=165&amp;w=165&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  class="thumbnail" /></a>
<?php } else { echo ''; } ?>
<?php the_content_limit(410, ""); ?>
</div>

</div>

<?php endwhile; ?>

<div style="clear: both;"></div>
<div style="margin-left: 110px; margin-top: 5px;">
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
else { ?>
<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>
<?php } ?>
</div>

<?php else : ?>

<h2 >No Results Found</h2>

<p>Sorry, your search returned zero results. </p>

<?php endif; ?>

</div>

<?php get_sidebar(); ?>  
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/content-bottom.gif" alt="logo" style="float: left;" />
</div>
  