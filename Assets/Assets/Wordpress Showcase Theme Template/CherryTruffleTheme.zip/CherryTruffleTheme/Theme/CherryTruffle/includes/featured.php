<?php $my_query = new WP_Query("category_name=Featured Articles&showposts=$artsee_homepage_featured;");
while ($my_query->have_posts()) : $my_query->the_post();
$do_not_duplicate = $post->ID; ?>
<div class="featured">

<span class="titles-featured"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></span><span class="featured-date">| <?php the_time('M jS, Y') ?></span>
<?php $thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);?>
<?php if($thumb !== '') { ?>
<div class="featured-thumb-wrapper">
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=223&amp;w=615&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  class="featured-thumb" /></a>
<div class="featured-categories"><?php the_category('') ?></div>
</div>
<?php } else { echo ''; } ?>
<div style="clear: both;"></div>
<?php the_content_limit(300, ""); ?>
</div>
<?php endwhile; ?>