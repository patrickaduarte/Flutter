
<a href="<?php echo $artsee_banner_468_url; ?>"><img src="<?php echo $artsee_banner_468; ?>" alt="banner ad" class="foursix" /></a>
