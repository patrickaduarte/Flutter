<div id="container2">
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/content-top-home-2.gif" alt="logo" style="float: left;" />
<div id="left-div">

<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>
<div class="post-wrapper" style="margin-bottom: 40px;">
<h1 class="titles2"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h1>
<div style="clear: both;"></div>
<div class="post-info">Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('m jS, Y') ?> |  <a href="#respond" title="<?php _e("Leave a comment"); ?>"><?php comments_number('no responses','one response','% responses'); ?></a></div>
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/comment-bottom.gif" alt="logo" style="float: left; margin-bottom: 20px;" />
<div style="clear: both;"></div>
<?php if (get_option('artsee_thumbnails') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/thumbnail.php'); } ?>
<?php the_content(); ?>
</div>
<?php endwhile; ?>

<div style="clear: both;"></div>
<div style="margin-left: 20px; margin-top: 5px;">
<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
else { ?>
<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>
<?php } ?>
</div>

<?php else : ?>

<h2 >No Results Found</h2>

<p>Sorry, your search returned zero results. </p>

<?php endif; ?>

</div>

<?php get_sidebar(); ?>  
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/content-bottom-2.gif" alt="logo" style="float: left;" />
</div>