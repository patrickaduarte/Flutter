<div id="footer">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Footer") ) : ?>
<?php endif; ?>
<div style="clear: both;"></div>
</div>
<div style="clear: both;"></div>
<div class="bottomfooter">
Powered by <a href="http://www.wordpress.org">Wordpress</a> | Designed by <a href="http://www.elegantthemes.com">Elegant Themes</a> 
</div>

</div>

<?php wp_footer(); ?>