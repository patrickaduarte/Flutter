<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php if (is_home()) : ?><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?>
<?php else : ?>
<?php wp_title('', 'false'); ?> - <?php bloginfo('name'); ?>
<?php endif; ?></title>

<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
<?php wp_get_archives('type=monthly&format=link'); ?>
<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style-<?php echo $artsee_cherry_color; ?>.css" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!--[if IE 7]>	
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/iestyle.css" />
<![endif]-->	
<!--[if lt IE 7]>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/ie6style-<?php echo $artsee_cherry_color; ?>.css" />
<script defer type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/pngfix.js"></script>
<![endif]-->
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/superfish.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/custom.js"></script>
<script type="text/javascript">
jQuery(function(){
jQuery('ul.superfish').superfish();
});
</script>
</head>

<body>

<div id="header">
<!--This controls the categories navigation bar-->
<div id="categories">
<ul class="nav superfish"><?php wp_list_cats("sort_column=$artsee_sort_cat&sort_order=$artsee_order_cat&optioncount=0&depth=3&exclude=$artsee_exclude_cat"); ?></ul>
</div>
<!--End category navigation-->
<div id="header-inside">
<a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/logo.png" alt="logo" class="logo" /></a>
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/separate.png" alt="separate" style="float: left; margin: 5px 15px 0px 15px;" />

<?php if (get_option('artsee_rss') == 'Disable') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/icon-rss.php'); } ?>

<?php if (get_option('artsee_twitter') == 'Disable') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/icon-twitter.php'); } ?>

<?php if (get_option('artsee_facebook') == 'Disable') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/icon-facebook.php'); } ?>

<?php if (get_option('artsee_myspace') == 'Disable') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/icon-myspace.php'); } ?>

<?php if (get_option('artsee_linkedin') == 'Disable') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/icon-linkedin.php'); } ?>

<?php if (get_option('artsee_stumble') == 'Disable') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/icon-stumble.php'); } ?>

<?php if (get_option('artsee_youtube') == 'Disable') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/icon-youtube.php'); } ?>

<div class="search_bg">
<div id="search">
<form method="get" action="<?php bloginfo('home'); ?>" style="padding:0px 0px 0px 0px; margin:0px 0px 0px 0px">
<input type="text"  name="s" value="<?php echo wp_specialchars($s, 1); ?>"/><input type="image" class="input" src="<?php bloginfo('stylesheet_directory'); ?>/images/search-button.png" value="submit"/>
					</form>
</div>
</div>

<div style="clear: both;"></div>
<div id="slogan">
<?php bloginfo('description'); ?>
</div>

<?php if (get_option('artsee_foursixeight') == 'Enable') { ?>
<?php include(TEMPLATEPATH . '/includes/468x60.php'); ?>
<?php } else { echo ''; } ?>

</div>
</div>
<div style="clear: both;"></div>
<!--This controls pages navigation bar-->
<div id="pages">
<ul class="nav superfish" id="nav2">
<?php if (is_home()) { ?>
<?php include(TEMPLATEPATH . '/includes/home-button.php'); ?>
<?php } else { include(TEMPLATEPATH . '/includes/home-button2.php'); } ?>
<?php wp_list_pages("sort_order=$artsee_order_page&depth=3&exclude=$artsee_exclude_page&title_li="); ?>
</ul>
</div>
<!--End pages navigation-->

<div id="wrapper2">