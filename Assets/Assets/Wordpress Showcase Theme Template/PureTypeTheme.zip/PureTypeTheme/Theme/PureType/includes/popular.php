<!--Begin Most Commented Articles-->
<span class="headings">popular articles</span>
<div class="home-sidebar-box">
<ul>
<?php
	$sql='SELECT post_title, comment_count, guid
		FROM wp_posts
		ORDER BY comment_count DESC
		LIMIT 8;';
	$results = $wpdb->get_results($sql);

	foreach ($results as $r) {
		echo '<li><a href="' . $r->guid . '" title="' . $r->post_title . '"> ' . $r->post_title .
			' (' . $r->comment_count . ')</a></li>';
	}
?>
</ul>
</div>
<!--End Most Commented Articles-->

<!--Begin Random Articles-->
<span class="headings">random articles</span>
<div class="home-sidebar-box">
<ul>
<?php $my_query = new WP_Query("orderby=rand&showposts=$artsee_random;");
while ($my_query->have_posts()) : $my_query->the_post();
?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '40') ?></a></li>
<?php endwhile; ?>
</ul>
</div>
<!--End Random Articles-->