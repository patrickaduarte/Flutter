<!--Begin Feaured Article-->
<?php if (get_option('artsee_featured') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/featured.php'); } ?>
<!--End Feaured Article-->

<div class="home-wrapper">

<div class="home-left">
<!--Begind recent post-->
<?php $my_query = new WP_Query("showposts=$artsee_homepage_posts&order=DESC");
while ($my_query->have_posts()) : $my_query->the_post(); $loopcounter++; ?>

<div class="home-post-wrap">	
<span class="post-info">Posted by <span style="color: #000;"><?php the_author() ?></span> | <?php the_time('M jS, Y') ?></span>
<div style="clear: both;"></div>
<?php if ($loopcounter == 1 || $loopcounter == 3 || $loopcounter == 5 || $loopcounter == 7 || $loopcounter == 9 || $loopcounter == 11) : ?>
<h2 class="titles"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '36') ?></a></h2>
<?php else : ?>
<h2 class="titles-orange"><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '36') ?></a></h2>
<?php endif; ?>
<div style="clear: both;"></div>

<?php $thumb = get_post_meta($post->ID, 'Thumbnail', $single = true); ?>
<?php if($thumb !== '') { ?>
<div class="thumbnail-div">
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=98&amp;w=98&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  style="border: none;" /></a>
</div>	
<?php } else { echo ''; } ?>

<?php the_content_limit(200, ""); ?>
</div>
<?php endwhile; ?>


<!--End recent post-->
</div>

<div class="home-right">
<?php if (get_option('artsee_popular') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/popular.php'); } ?>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Homepage") ) : ?>
<?php endif; ?>
</div>

</div>