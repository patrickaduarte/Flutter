<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php if (is_home()) : ?><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?>
<?php else : ?>
<?php wp_title('', 'false'); ?> - <?php bloginfo('name'); ?>
<?php endif; ?></title>

<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
<?php wp_get_archives('type=monthly&format=link'); ?>
<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style-<?php echo $artsee_color; ?>.css" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!--[if IE 7]>	
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/iestyle.css" />
<![endif]-->	
<!--[if IE 8]>	
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/ie8style.css" />
<![endif]-->	
<!--[if lt IE 7]>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/ie6style.css" />
<![endif]-->
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/superfish.js"></script>
<script type="text/javascript">
jQuery(function(){
jQuery('ul.superfish').superfish();
});
</script>
</head>

<body>

<!--This controls pages navigation bar-->
<div id="pages">
<div id="pages-inside">
<div id="pages-inside-2">
<ul class="nav superfish" id="nav2">
<li class="page_item"><a href="<?php bloginfo('url'); ?>" class="title" title="home again woohoo">Home</a></li>
<?php wp_list_pages("sort_order=$artsee_order_page&depth=3&exclude=$artsee_exclude_page&title_li="); ?>
</ul>

<div class="search_bg">
<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<div><input type="text" value="<?php the_search_query(); ?>" name="s" id="s" />
<input type="submit" id="searchsubmit" value="Search" />
</div>
</form>

</div>

</div>
</div>
</div>
<div style="clear: both;"></div>
<!--End pages navigation-->

<div id="wrapper2">

<div class="logo">
<span class="bluetitle"><a href="<?php bloginfo('url'); ?>"><?php echo $artsee_title_red; ?></a></span><span class="redtitle"><a href="<?php bloginfo('url'); ?>"><?php echo $artsee_title_blue; ?></a></span>
</div>
<div class="slogan"><?php bloginfo('description'); ?></div>

<!--This controls the categories navigation bar-->
<div id="categories">
<ul class="nav superfish"><?php wp_list_cats("sort_column=$artsee_sort_cat&sort_order=$artsee_order_cat&optioncount=0&depth=3&exclude=$artsee_exclude_cat"); ?></ul>
</div>
<!--End category navigation-->